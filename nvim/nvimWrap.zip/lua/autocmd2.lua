--'''
--#vim.command(
--#autocmd BufNewFile,BufRead,BufEnter /*.py setf python
--#autocmd BufNewFile,BufRead,BufEnter /*.vim setf vim
--#autocmd BufNewFile,BufRead,BufEnter /*.lua setf lua
--#autocmd BufNewFile,BufRead,BufEnter /*.html setf html
--        #"*.c", "*.h", '*.vim'
--)
--'''
--local M={}
--M.rtrvFtype=function()
--    --from os.path import splitext
--    --import vim
--    local fname=vim.fn.expand('%')
--    --base, ext=splitext(fname)
--    print('fname=', fname, string.find(fname, '.'))
--    --local ftype=ext[1:]
--    --vim.cmd(setf ftype)
--end
--return M
vim.api.nvim_create_autocmd({"BufEnter", "BufWinEnter", 'BufRead'}, { pattern={'*'}, callback=function()
      local fname=vim.fn.expand('%')
    --print('fname=', fname, string.find(fname, '.', 1))
    local ext=fname:match('[^.]+$') --"^.*?\.[.*?]$"  .+/(.+) "^.+/(.+)\\.(.+)$"
    if not ext==nil then
      ext=ext:gsub("\\.", "")
      vim.cmd[[setf ext]]
      --vim.eval('setf ext')
    end
end})
