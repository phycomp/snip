vim.api.set_keymap('n', '<leader>erc', '<cmd>edit ~/.config/nvim/init.vim<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>so', '<cmd>source %<CR>', {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>fd', '<cmd>filetype detect<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>ev', '<cmd>edit $MYVIMRC<CR>', {'noremap':True, 'silent':False})
