import pynvim

@pynvim.command('bufEmulator', nargs='n', range='', sync=True)
def bufEmulator(*args):
  print(*args)
  vim.command(f'bo {args}')
#bufEmulator(...)
#:command -nargs=+ -complete=command bufEmulator call bufEmulator(<q-args>)
#bo term ++close ++rows=
vim.api.open_term(bufnr, {})
#py3 import vim; rtrvTerm=lambda x:return x;vim.api.open_term(4, {'on_input':rtrvTerm})
