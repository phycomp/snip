#-*- coding:utf-8 -*-
def ridPttrn():
    #—import pynvim
    from re import search as reSrch
    from UltiSnips.position import Position
    #from UltiSnips.compatibility import col2byte, byte2col
    from UltiSnips.vim_helper import set_cursor_from_pos, get_cursor_pos, escape
    from re import sub as reSub
    import vim
    curPos=get_cursor_pos()
    buf = vim.current.buffer
    lastLnum = buf.api.line_count()
    Lnum=1  #vim.api.line(1)
    keyPunct=['丨', '%', '｜', '︔', '︕', '⋅', '︓', '|', '恊', '﹐', '﹑', '＇', '–', '﹕', '│', 'ﾞ', 'ﾞ', '〝', '〞', '·', '=', '＊', '∼', '＜', '＞', '〖', '〗', '`', '＃', '丶', '•', '﹔', '〃', '◆', '︰', '_', '○', '．', '‘', '×', '’', '－', '°', '｡', '﹒', '~', '─', '#', '〜', '～', '…', '　', '"',  "：", '；', '、', '，', ';', ',', '。', ':', '※', '‧']
    keyQuote=['︐', '｛', '｝', '｢', '｣', '«', '»', '●', '＂', '＂', '﹄','﹃', '—', '﹙', '﹚', '<', '>', '︵', '︶', '﹁', '﹂', '〔', '〕' '【', '】', '「', '」', '《', '》', '〈', '〉', '﹝', '﹞', '』', '『', '（', '）', '！', '［', '］', '“', '”']
    keyEscape=[' ', '@', '*', '!', '-', '+', '(', ')', '.', '/', '[', ']', '{', '}']
    #[:escape:]*	  [:escape:]		the <Esc> character
    #[:backspace:]*	  [:backspace:]		the <BS> character
    #[:ident:]*	  [:ident:]		identifier character (same as "\i")
    #[:keyword:]*	  [:keyword:]		keyword character (same as "\k")
    #[:fname:]*	  [:fname:]		file name character (same as "\f")
    curLnum, nbyte = vim.current.window.cursor
    curRaw=buf[curLnum-1]
    curRawEncode=curRaw.encode(vim.eval("&encoding"), "replace")
    rawBytes = curRawEncode[:nbyte]
    col= len(rawBytes.decode(vim.eval("&encoding"), "replace"))
    #col = byte2col(curLnum, nbyte)
    pos=Position(curLnum - 1, col)
    try: cword=curRaw[pos.col]
    except: cword=vim.api.get_current_line()
    #if vim.funcs.match(cword, '[^\\u0000-\\u007F]')==-1: cword=None
    #except: cword=vim.api.get_current_line()
    #print('cword=', cword)
    punctCword=''.join(keyPunct)
    punctCword, punctSbsttword=f'[{punctCword}]', ' '

    quoteSbsttword=''
    quoteCword=''.join(keyQuote)
    quoteCword=f'[{quoteCword}]'

    escapeSbsttword=''
    escapeCword='\\'.join(keyEscape)
    escapeCword=f'[{escapeCword}]'
    #print('in keyEscape=', cword in keyEscape)
    #print('cword, escapeCword=', cword, escapeCword, escapeSbsttword)
    vim.command('normal! gg')
    newRaw=None
    while Lnum<=lastLnum:
        curRaw=vim.api.get_current_line()
        #curChar=escape(curRaw)
        if any([ p in curRaw for p in keyPunct]):   #==True
            if curRaw.find('http')!=-1:
              punctCWORD=punctCword.replace('=', '').replace(':', '').replace('_', '')
            else: punctCWORD=punctCword
            curRaw=reSub(punctCWORD, punctSbsttword, curRaw)
        if any([ q in curRaw for q in keyQuote]):   #==True
            curRaw=reSub(quoteCword, quoteSbsttword, curRaw)
        if quoteCword:
            curRaw=reSub(quoteCword, quoteSbsttword, curRaw)
        if any([ e in curRaw for e in keyEscape]):  #==True
            if curRaw.find('http')!=-1:
              escapeCWORD=escapeCword.replace('.', '').replace('/', '')    #.replace(':', '')
            #else: curRaw=reSub(escapeCword, escapeSbsttword, curRaw)
            #[^\u4E00-\u9FFF|，：。；、! ！#0-9:\.？]
              curRaw=reSub(escapeCWORD, escapeSbsttword, curRaw)
            else: curRaw=reSub(escapeCword, escapeSbsttword, curRaw)
        #if curRaw.find('http')!=-1: pass
        #else: curRaw=reSub('(?![\u4E00-\u9FFF| ]).', '', curRaw)    #[\u0000-\uFFFF]
        #elif cword and reSrch('(?![\u4E00-\u9FFF]).', cword):  #[\u0000-\uFFFF]
        #vim.funcs.match(cword, '^((?![\u0000-\uFFFF]).)*')!=-1:'^((?![\u0000-\uFFFF]).)*'
        #elif cword and vim.funcs.match(cword, '[\\u4e00-\\u9fa5]')==-1:'[\\uffff-\\Uffffff]'
            #curRaw=reSub('^((?![\u0000-\uFFFF]).)*', '', curRaw)
            #curRaw=reSub('(?![\u4E00-\u9FFF]).', '', curRaw)    #[\u0000-\uFFFF]
        #curRaw=reSub(cword, '', curRaw)    #, 'g'
        vim.api.set_current_line(curRaw)
        if curRaw=='\':vim.api.del_current_line()    #vim.funcs.deletebufline()del buf[Lnum]#
        else: vim.command('normal! j')
        Lnum+=1
    set_cursor_from_pos(curPos)
#nnoremap <silent> <leader>rp :python3 ridPttrn.ridPttrn()<CR>
vim.api.set_keymap('n', '<leader>rp', "<cmd>python3 ridPttrn()<CR>", {'noremap':True, 'silent':False})
