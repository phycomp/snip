from math import ceil as mthCeil
def rtrvOPT():
  #ui=vim.api.list_uis()[0]
  #width, height=ui.get('width'), ui.get('height')
  #opts={'relative':'editor', 'width':width, 'height':height, 'col':width/2-(width/2), 'row':height/2-(height/2), 'anchor':'NW', 'style':'minimal'}
  width=vim.api.get_option('columns')
  height=vim.api.get_option('lines')
  winHeight=mthCeil(height*.8 - 4)
  winWidth=mthCeil(width*.8)
  row=mthCeil((height-winHeight)/2 - 1)
  col=mthCeil((width-winWidth)/2)
  opts={'style':'minimal', 'relative':'editor', 'width':winWidth, 'height':winHeight, 'row':row, 'col':col, 'border':'rounded'}
  return opts

def bufWin(msg):
  bufnr=vim.api.create_buf(False, True)
  vim.api.buf_set_lines(bufnr, 0, -1, True, msg)
  opts=rtrvOPT() #{'relative':'cursor', 'width':10, 'height':2, 'col':0, 'row':1, 'anchor':'NW', 'style':'minimal'}
  winnr=vim.api.open_win(bufnr, 0, opts) #optional: change highlight, otherwise Pmenu is used
  vim.api.set_option_value('winhl', 'Normal:MyHighlight', {'win':winnr})
  return bufnr, winnr

def vwrCMD(*args):
  bufnr=vim.api.create_buf(False, True)
  #vim.api.buf_set_lines(bufnr, 0, -1, True, msg)
  opts=rtrvOPT() #{'relative':'cursor', 'width':10, 'height':2, 'col':0, 'row':1, 'anchor':'NW', 'style':'minimal'}
  winnr=vim.api.open_win(bufnr, 0, opts) #optional: change highlight, otherwise Pmenu is used
  vim.api.set_option_value('winhl', 'Normal:MyHighlight', {'win':winnr})
  CMD=' '.join(args)
  vim.command('setlocal buftype=nofile')
  vim.command(CMD)
  return bufnr, winnr
