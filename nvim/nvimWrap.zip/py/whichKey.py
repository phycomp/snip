#:WhichKey " show all mappings
#:WhichKey <leader> " show all <leader> mappings
#:WhichKey <leader> v " show all <leader> mappings for VISUAL mode
#:WhichKey '' v " show ALL mappings for VISUAL mode
vim.api.set_keymap('n', '<leader>wk', '<cmd>WhichKey<CR>', {'noremap':True, 'silent':True})
vim.api.set_keymap('n', '<leader>wkv', "<cmd>WhichKey '' v<CR>", {'noremap':True, 'silent':False})
