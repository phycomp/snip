rtp=vim.api.list_runtime_paths()
rtp.insert(0, '/home/josh/GITs/htmlgui.nvim')
print(rtp)

#let @*=execute('pwd')
#/home/josh/GITs/htmlgui.nvim
