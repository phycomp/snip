#vim.api.guifont="Source Code Pro:h14"
def rtrvFont():
  if vim.funcs.has("gui_running"):
    guiFont=vim.api.get_option('guifont')
    if not guiFont: guiFont='華康隸書體W5:h14:#h-slight'  #DFWeiBei-B5 華康魏碑體
    fntFamily, fntSize=guiFont.split(':')[:2]
    return fntFamily, fntSize
def IncreaseFont():
  fntFamily, fntSize=rtrvFont()
  fntSize=int(fntSize[1:])
  fntSize+=1
  vim.api.set_option('guifont', f'{fntFamily}:h{fntSize}')
def DecreaseFont():
  fntFamily, fntSize=rtrvFont()
  fntSize=int(fntSize[1:])
  fntSize-=1
  vim.api.set_option('guifont', f'{fntFamily}:h{fntSize}')
vim.api.set_keymap('n', '<C-ScrollWheelUp>', '<cmd>py3 IncreaseFont()<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<C-ScrollWheelDown>', '<cmd>py3 DecreaseFont()<CR>', {'noremap':True, 'silent':False})
