from re import search
def setComment():
  bufFtype=vim.eval('&filetype')
  if bufFtype=='python':
    curRaw=vim.api.get_current_line()
    if curRaw.find('#')!=-1:
      curRaw=curRaw.replace('#', '')    #, 'g'
      vim.api.set_current_line(curRaw)
    else:
      if mtch:=search(r'^(\s+)(.*)', curRaw):
        空白, 字串=mtch.groups()
        vim.api.set_current_line(f'{空白}#{字串}')
      else:
        vim.api.set_current_line(f'#{curRaw}')

def unComment():
  bufFtype=vim.eval('&filetype')
  if bufFtype=='python':
    curRaw=vim.api.get_current_line()
    vim.api.set_current_line(f'{curRaw[1:]}')
#bufFtype=None
vim.api.set_keymap('n', '<leader>cmt', '<cmd>py3 setComment()<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>ucmt', '<cmd>py3 unComment()<CR>', {'noremap':True, 'silent':False})
