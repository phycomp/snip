from .views import CrudMDL

    path('crudURL', CrudMDL.as_view(), name='crudURL'),

class CrudMDL(View):
  def post(self, request):
    tid=request.body.decode('utf-8')
    tid, 主旨, 內容, 附件=rnderTID(request, tid)
    from django.template import loader
    tmpl=loader.get_template('tmpl-附件.html')
    if 附件:
      附件=附件.split('\x06')
    cntxt=tmpl.render({'tid':tid, '主旨':主旨, '內容':內容, '附件':附件}, request)
    return JsonResponse({'cntxt':cntxt})

queryTID=()=>{
  headerInfo['body']=tid=SELV.getAttribute('tid')
  fetch("{% url 'crudURL'%}", headerInfo).then(response=>response.json()).then(rspData=>{
    dataRSP=rspData
    qryRSLT.innerHTML = '<pre>'+rspData.cntxt+'</pre>'
  })
}

