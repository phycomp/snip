from .views import 更新CrudMDL, 編輯CrudMDL

from django.urls import include, path
    path('crudURL-更新', 更新CrudMDL.as_view(), name='crudURL-更新'),
    path('crudURL-編輯', 編輯CrudMDL.as_view(), name='crudURL-編輯'),

class CrudMDL(View):
  def post(self, request):
    rqstPst=request.POST
    tid, 主旨, 內容=rqstPst['tid'], rqstPst['主旨'], rqstPst['內容']
    內容=內容.replace("'", "''").replace('"', '""')
    #frmAttached=request.FILES.getlist('附件')
    runQuery(f'''update isc8381."TechwikiMnpltn" set (主旨, 內容)=('{主旨}', '{內容}') where id='{tid}';''', db='bdtest', qryType='update')   #主旨, 內容, 附件 and 附件 is not null
    return JsonResponse({'更新':True})

from django.http import JsonResponse
from dbMnpl.strmltPGconn import runQuery
  def post(self, request):
    #return JsonResponse({'addTchwk':request.POST})
    rqstPst=request.POST
    主旨, 內容=rqstPst['主旨'], rqstPst['內容']
    內容=內容.replace("'", "''").replace('"', '""')
    frmAttached=request.FILES.getlist('附件')
    #appendlist, clear, copy, dict, encoding, fromkeys, get, getlist, items, keys, lists, pop, popitem, setdefault, setlist, setlistdefault, update, urlencode, values
    allImg=[]
    for fin in frmAttached:
      b64Str=b64encode(fin.read()).decode()
      allImg.append(b64Str)
    附件='\x06'.join(allImg)
    fullQuery=runQuery(f'''insert into isc8381."MDLMnpltn" (主旨, 內容, 附件) values('{主旨}',  '{內容}', '{附件}');''', db='bdtest', qryType='insert')
    return JsonResponse({'addTchwk':True})""" 
    #return JsonResponse({'info':allImg})

<nav>
  <input type=radio title=tchwkID name=tchwkID checked>tchwkID
  <input type=radio title=updateTID name=tchwkID>updateTID
  <input type=search name=srchTchwk title='fox & (dog | clown)!queen, sphinx<->quartz' placeholder='fox & (dog | clown)!queen, sphinx<->quartz'>
</nav>
<form name=frmAttached enctype='multipart/form-data'>
  <div name=主旨 type=text title=主旨 contenteditable placeholder=主旨></div>
    <textarea name=內容 rows=8 placeholder=內容></textarea>
    <input name=附件 type=file multiple>
</form>

<style>
form[name=frmAttached]{display:grid; grid-template-rows:repeat(auto-fit, minmax(1vh, 1fr)); }
textarea[name=內容]{display:grid; }
</style>

<script>
tchwkID=document.querySelector('input[title=tchwkID]')
updateTID=document.querySelector('input[title=updateTID]')
srchTchwk.addEventListener('keydown', evt=>{
  //const formdata=new FormData({:ele});
  if (evt.keyCode===13 && evt.ctrlKey) {
      SELV=evt.target
      headerInfo['body']=qryTerm=SELV.value
      if (updateTID.checked) {主旨.setAttribute('tid', qryTerm); 
        fetch("{%url 'crudURL-編輯'%}", headerInfo).then(response=>response.json()).then(rspData=>{
          內容.value=rspData.內容
          主旨.innerText=rspData.主旨
        })
       }
      else fetch("{%url 'search-tchwk'%}", headerInfo).then(response=>response.json()).then(rspData=>{
        qryRSLT.innerHTML=rspData.qryTchwk    //.replace('\n', '<br>')
        SELV.value=''
      })
  }
})
</script>
