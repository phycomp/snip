from .views import CrudMDL
    path('crudURL', CrudMDL.as_view(), name='crudURL'),

from django.http import JsonResponse
from dbMnpl.strmltPGconn import runQuery
class CrudMDL(View):
  def post(self, request):
    #return JsonResponse({'addTchwk':request.POST})
    rqstPst=request.POST
    主旨, 內容=rqstPst['主旨'], rqstPst['內容']
    內容=內容.replace("'", "''").replace('"', '""')
    frmAttached=request.FILES.getlist('附件')
    #appendlist, clear, copy, dict, encoding, fromkeys, get, getlist, items, keys, lists, pop, popitem, setdefault, setlist, setlistdefault, update, urlencode, values
    allImg=[]
    for fin in frmAttached:
      b64Str=b64encode(fin.read()).decode()
      allImg.append(b64Str)
    附件='\x06'.join(allImg)
    fullQuery=runQuery(f'''insert into isc8381."TechwikiMnpltn" (主旨, 內容, 附件) values('{主旨}',  '{內容}', '{附件}');''', db='bdtest', qryType='insert')
    return JsonResponse({'addTchwk':True})

<form name=frmAttached enctype='multipart/form-data'>
  <div name=主旨 type=text title=主旨 contenteditable placeholder=主旨></div>
    <textarea name=內容 rows=8 placeholder=內容></textarea>
    <input name=附件 type=file multiple>
</form>

<style>
form[name=frmAttached]{display:grid; grid-template-rows:repeat(auto-fit, minmax(1vh, 1fr)); }
textarea[name=內容]{display:grid; }
</style>	

<script>
frmAttached.addEventListener('keydown', evt=>{
  formData=new FormData(frmAttached)
  value內容=內容.value
  value主旨=主旨.innerText
  if (evt.keyCode===13 && evt.ctrlKey)
    if (value內容 && value主旨) {
      formData.append('主旨', value主旨)
      headerInfo['body']=formData
      fetch("{%url 'crudURL'%}", headerInfo).then(response=>response.json()).then(rspData=>{
        qryRSLT.innerHTML='<pre>'+value內容.replaceAll('\n', '<br>')+'<pre>'
        frmAttached.reset()
        主旨.innerText=''
      })
    }
})
</script>	
