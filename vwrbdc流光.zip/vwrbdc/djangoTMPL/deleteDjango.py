from django.http import JsonResponse
from .views import CrudMDL#, 更新Tchwk, 編輯Tchwk, RndrToml, QueryTchwkID, AddTechwiki, SearchTechwiki, InitTechwiki, AllTechwiki	#PostEdit, PostDetail, PostCommentSelf, PostCommentSelfEdit, PostCommentSelfDelete, PostContextEdit, PostCommentEdit, PostCommentDelete, PostDelete, PostComment, WallAdd, PostMediaDelete	#PostPagination, 

    path('crudURL/', CrudMDL.as_view(), name='crudURL'),

class CrudMDL(View):
  def post(self, request):
    tid=request.body.decode('utf-8')
    runQuery(f'delete from isc8381."TechwikiMnpltn" where id={tid};', db='bdtest', qryType='delete')
    return JsonResponse({'crudMDL':True})

rmTAG=(SELV)=>{
  tid=SELV.getAttribute('tid')
  headerInfo["body"]=tid
  fetch("{%url 'crudURL'%}", headerInfo).then(response=>response.json()).then(rspData=>{
    //qryRSLT.innerHTML=rspData.qryTchwk
    SELV.previousElementSibling.remove()
    SELV.remove()
    SELV.value=''
    console.log(rspData.crudMDL)
  })
}

