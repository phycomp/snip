import React, { useEffect, useState } from "react";
import { Streamlit, withStreamlitConnection } from "streamlit-component-lib";

const AnnttNER = (props) => {
  const clicked = useState(0);

  useEffect(() => {
    Streamlit.setFrameHeight();
  });
  return (
    <div>
      <h1>Hello CodeSandbox</h1>
    </div>
  );
};

export default withStreamlitConnection(AnnttNER);


import React, { useEffect, useState, ReactNode } from "react"
import {withStreamlitConnection, StreamlitComponentBase, Streamlit} from "streamlit-component-lib"
//import { embed } from "@bokeh/bokehjs";
import "./ner.css"

interface State {
  eventDetailMap: Map<string, object>;
}

class AnnttNER extends StreamlitComponentBase<State> {
  public state = { eventDetailMap: new Map() , dlmtr:'|', nerInfo:{}, nerPos:[], minPOS:[]
  }

  /*
  debounced(delay: number, fn: Function) {
    let timerId: any;
    return function (...args: any[]) {
      if (timerId) clearTimeout(timerId);
      
      timerId = setTimeout(() => { fn(...args);
        timerId = null; }, delay);
    }
  }

  
  _plotChart() {
    const chart: any = document.getElementById(this.props.args["_id"])

    // empty the element
    while (chart.lastChild) 
      chart.lastChild.remove()
    
    const events = this.props.args["events"]
    const debounceTime = this.props.args["debounce_time"]

    events.split(",").forEach((eventName: string) => document.addEventListener(eventName.trim(), this.debounced(debounceTime, this.handleEvent.bind(this))))

    const bokehJson = this.props.args["bokeh_plot"]
    const figure = JSON.parse(bokehJson)
    embed.embed_item(figure)
    const plot = figure && figure.doc && figure.doc.roots && figure.doc.roots.references
        ? figure.doc.roots.references.find((e: any) => e.type === "Plot")
        : undefined
    // if height is not defined pick up the default bokeh plot height.
    let height = (plot && plot.attributes.plot_height) || 600;
    if (this.props.args["override_height"]) {
      height = this.props.args["override_height"]
    }
    Streamlit.setFrameHeight(height);
  }



  componentWillUnmount() {
    const events = this.props.args["events"]
    const debounceTime = this.props.args["debounce_time"]
    // unsure whether removal of listener is correct or not
    events.split(",").forEach((eventName: string) => document.removeEventListener(eventName.trim(), this.debounced(debounceTime, this.handleEvent.bind(this))))
  }
  componentDidMount() {
    this.setState(
    Streamlit.setComponentValue(this.state.minPOS)

        )
}

  componentDidMount() {
  //if ( this.props.args["refresh_on_update"]) this._plotChart();
  Streamlit.setFrameHeight(1200)
  }
  */
handleComponentValue=()=>{
    console.log(this);
    Streamlit.setComponentValue(this.state.minPOS)
  }

rndrNER=()=>{
  let psttnStart, psttnEnd, colorNer
  let medLtrtr=document.querySelector('div[name=medLtrtr]')
  console.log('medLtrtr.length', medLtrtr.innerText.length);
  let newSlctn=document.querySelector('div[name=newSlctn]')
  var mdLtrtrInfo=medLtrtr.innerText
  console.log('mdLtrtrInfo.length', mdLtrtrInfo);
  var lastNdx=this.state.minPOS.length-1
  //console.log('minPOS', minPOS);
  var fullNER=''
  console.log('minPOS', this.state.minPOS);
  this.state.minPOS.forEach((psttnInfo, ndx)=>{
    //console.log('psttnInfo', psttnInfo);
    [psttnStart, psttnEnd, colorNer]=psttnInfo
    var [NerDscrptn, clrNER]=colorNer.split(this.state.dlmtr)
    var spanNER=mdLtrtrInfo.slice(psttnStart, psttnEnd)
    var nerOutput=`<span title=${NerDscrptn} style='color:${clrNER}'>${spanNER}</span>` //eval()
    //mdLtrtrInfo.slice[psttnInfo]
    //if(!ndx) {fullNER=mdLtrtrInfo.slice(0, psttnStart)+ nerOutput//console.log();
      if(!ndx)frmrEnd=0
      else var [frmrStart, frmrEnd, frmrNerClr]=this.state.minPOS[ndx-1]
      //console.log('frmrEnd', frmrEnd);
      fullNER+=mdLtrtrInfo.slice(frmrEnd, psttnStart)+ nerOutput
  })
  //console.log('psttnEnd', psttnEnd);
  fullNER+=mdLtrtrInfo.slice(psttnEnd)//console.log();
  newSlctn.innerHTML=fullNER
  //this.handleComponentValue()
}

isEmpty = (SELF)=>{
  for(var key in SELF)
    if(SELF.hasOwnProperty(key)) return false
  return true
}

srchMinPos=(SELF)=>{
  let rsltPos, selvPOS, minStart, minEnd, minTerm, minINFO, minPOS, minNdx
  minStart=Infinity
  for (const [nerTerm, v] of Object.entries(SELF)){
    v.forEach(posInfo=>{
      var [posStart, posEnd]=posInfo
      if (minStart>posStart){rsltPos=posInfo; minStart=posStart; minEnd=posEnd; minTerm=nerTerm}
    })
  }
  selvPOS=SELF[minTerm]//.map(x=>x)
  minNdx=selvPOS.indexOf(rsltPos)  //[minStart, minEnd]
  minINFO=selvPOS.splice(minNdx, 1)[0]
  minINFO.push(minTerm)
  this.state.minPOS.push(minINFO)
  if(!selvPOS.length)  delete SELF[minTerm] //{}console.log('delete'); SELV.pop(minTerm)
  else SELF[minTerm]=selvPOS
  if(this.isEmpty(SELF)) console.log('return minPOS');
  else this.srchMinPos(SELF)
}

/*
*/
getState=(stateTerm)=>{
  return this.state[stateTerm]
}

init=()=>{
  this.state.nerInfo={}
}
lblNER=(evt)=>{
  //console.log('props', this)     //{}
  //console.log('Prop', Prop)     //undefined
  //console.log('evt', evt)       //clickEvent
  var SELV=evt.target
  //console.log('SELV', SELV);
  var nerPos=this.state.nerPos
  if(!nerPos.length) return
  var nerColor=window.getComputedStyle(SELV).color
  var nerTerm=[SELV.innerText, nerColor].join(this.state.dlmtr)
  //var nerInfo=useState('nerInfo')
  var nerInfo=this.getState('nerInfo')
  var tmpPos=nerInfo.hasOwnProperty(nerTerm)?nerInfo[nerTerm]:[]
  if(!tmpPos.length) {tmpPos.push(nerPos)
    this.state.nerInfo[nerTerm]=tmpPos}
  else
  {var psudoPos=tmpPos[0]
    if(psudoPos[0]===nerPos[0]&&psudoPos[1]===nerPos[1]) return
    else {tmpPos.push(nerPos)
    this.state.nerInfo[nerTerm]=tmpPos}
  }
  this.state.nerPos=[]
  this.state.minPOS=[]
  var infoNER=JSON.parse(JSON.stringify(this.state.nerInfo))
  this.srchMinPos(infoNER)//
  this.rndrNER()
}

  nerSlctn=()=>{
    //this._plotChart();
    let SLCTN=window.getSelection()
    if(SLCTN.isCollapsed) return
    var startPos=SLCTN.anchorOffset
    var endPos=SLCTN.focusOffset
    this.state.nerPos=[startPos, endPos]
    this.setState({nerPos:this.state.nerPos})
  //useEffect(() => Streamlit.setFrameHeight(1200));
  }

  render = (): ReactNode =>{
    //console.log(this.props.args);
    var medLtrtr=this.state.medLtrtr=this.props.args['medLtrtr']
    console.log('medLtrtrlength', medLtrtr.length);
    var newSlctn=document.querySelector('div[name=newSlctn]')
    if (newSlctn) newSlctn.innerText=''
    this.init()
    //var lblNER=this.props.args['lblNER']
    return (
      <div name="nerWrapper">
<div name="medLtrtr" onDoubleClick={this.nerSlctn}>{medLtrtr}</div>
  <div name="TAGs">
    <div onClick={this.lblNER} name="Finding">Finding</div>
    <div onClick={this.lblNER} name="Classification">Classification</div>
    <div onClick={this.lblNER} name="Gross">Gross</div>
    <div onClick={this.lblNER} name="Pit">Pit</div>
    <div onClick={this.lblNER} name="NICE">NICE</div>
    <div onClick={this.lblNER} name="Position1">Position1</div>
    <div onClick={this.lblNER} name="Position2">Position2</div>
    <div onClick={this.lblNER} name="Procedure">Procedure</div>
    <div onClick={this.lblNER} name="NoneProcedure">NoneProcedure</div>
    <div onClick={this.lblNER} name="Size">Size</div>
    <div onClick={this.lblNER} name="Grade">Grade</div>
    <div onClick={this.lblNER} name="Margin">Margin</div>
    <div onClick={this.lblNER} name="Base">Base</div>
    <div onClick={this.handleComponentValue} name="componentValue">componentValue</div>
  </div>
  <div name="newSlctn"></div>
</div>
    )
  }
}
export default withStreamlitConnection(AnnttNER)
