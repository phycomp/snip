from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, Table
from config import metadata
from datetime import datetime


''' SQLAlchemy Model'''
posts = Table( "posts", metadata,
    Column("id", Integer, primary_key=True),
    Column("title", String(100), unique=True),
    Column("body", Text),
    Column("is_published", Boolean),
    Column("created", DateTime, default=datetime.utcnow().strftime("%Y-%m-%d" "%H:%M:%S")),
    Column("modified", DateTime, default=datetime.utcnow().strftime("%Y-%m-%d" "%H:%M:%S"))
)

