# FastAPI-CRUD
FastAPI CRUD Example

![](screenshot.png)
