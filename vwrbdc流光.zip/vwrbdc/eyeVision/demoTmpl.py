from fastapi import FastAPI, Request, Form
#from scrapes.scrape_corner import C_t3
#from apis.general_pages.route_homepage import general_pages_router
from fastapi.templating import Jinja2Templates
from fastapi import Request
import pathlib
from fastapi.responses import HTMLResponse

BASE_DIR = pathlib.Path(__file__).resolve().parent  # app/
TEMPLATE_DIR = BASE_DIR / "templates"  # / "general_pages"

app = FastAPI()
templates = Jinja2Templates(directory=str(TEMPLATE_DIR))

#data_t3 = C_t3()

'''

def include_router(app):
    return app.include_router(general_pages_router)
'''

@app.get("/scrape", status_code=200)
async def scraper(request: Request):
  context = {"request":request, 'info':'HERE IS THE ISSUE'} #data_t3.scraper_t3()[0]
  print(context)
  return templates.TemplateResponse("pthlgyTxtarea.html", context)
