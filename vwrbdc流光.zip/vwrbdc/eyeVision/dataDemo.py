from fastapi import FastAPI, Form, Depends
from pydantic.fields import Text
from pydantic.dataclasses import dataclass

app = FastAPI()

@dataclass
class UserFormModel:
    username: str = Form("default name")
    age: str = Form(22)
    gender: str = Form(None) # default = null
    email: str = Form(...) # required


@app.post("/form-data")
async def create_form_data(form_data: UserFormModel = Depends()):
    return form_data
