from re import search
def mkSghtIVI(iviSght):
    for ivi, sghtInfo in iviSght.items():
        #print('oriIVI', ivi, sghtInfo)  #IVIL
        if oriSGHT:=eyeCntnr.get(ivi):  #{"OD": "20100117|20111212|20120118|20120427|20120810"}
            finalDate=set()
            for oriSght, oriDATE in oriSGHT.items():  #{OD:xxx, OS:yyy}
                #print('oriSght', oriSght, oriDATE)
                for date in oriDATE.split('|'): finalDate.add(date) 
                if newDate:=sghtInfo.get(oriSght):
                  [ finalDate.add(date) for date in newDate.split('|') ]
                  tinyFull={oriSght:'|'.join(finalDate)}
                else:
                  tinyFull.update({oriSght:oriDATE})
            fullInfo={ivi:tinyFull}
            eyeCntnr.update(fullInfo)
        else:
            eyeCntnr.update(iviSght)
    return eyeCntnr  #print('eyeCntnr', eyeCntnr)

for line in eyeInfo.split('\n'):
    rtrvInfo=line.split('#')[-1]
    if search('@', rtrvInfo):
        iviSght=eval(rtrvInfo.split('@')[0])
        fullSghtIVI=mkSghtIVI(iviSght)
    elif search('|', rtrvInfo): #6/15|6/6
        pass
    else:
        fullSghtIVI=mkSghtIVI(eval(rtrvInfo))
    print(line, fullSghtIVI)

