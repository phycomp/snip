from dbUtil import runQuery
from stUtil import rndrCode
from streamlit import dataframe, write as stWrite
from pandas import DataFrame

def dataIntegrity():
  #from pandas import read_csv
  #df=read_csv('IVILOAE.csv', delimiter='\x06', dtype='str')
  #df.apply(rtrvIVI, axis=1)
  #df[['OD', 'OS']]=df[['OD', 'OS']].astype(float)
  #df['OD']=df['OD'].apply(vl2Float) #=df['OD']==''.fillna(0).astype(float)
  #df['OS']=df['OS'].apply(vl2Float) #=df['OD']==''.fillna(0).astype(float)
  #df['OS']=df['OS'].fillna(0).astype(float)
  #df=df.set_index('DATE')
  #df=df.rename(columns={'DATE':'index'}).set_index('index')
  #from altair import Chart, X, Y, Axis
  #sghtChart = Chart(df).mark_line().encode( x=X('DATE', axis=Axis(labelOverlap="greedy", grid=False)), y=Y('OD/OS'))
  #spcfcSght=session_state['spcfcSght']
  #altair_chart(sghtChart)  #[df.OD, df.DATE]
  qryRslt=runQuery('select * from 眼科2024 limit 50;', db='eyeVis')
  #rndrCode(qryRslt)
  eyeDF=DataFrame(data=qryRslt, columns=["病歷號", "日期", "眼科文本", "眼科代碼", "視力眼壓", "打針"])
  dataframe(eyeDF)

