from 眼科.srchHIST import 病人針視  #, 找病人
from streamlit import columns as stCLMN, line_chart, dataframe
from pandas import DataFrame
from matplotlib.pyplot import figure, scatter
from stUtil import rndrCode

eyeScale={'CF':.01, 'HM':.001, 'LP':.0001, 'NLP':.00001}  #CF是logMAR 2. 等於 1/100=.01 HM是logMAR 3. 等於1/1000=.001 LP是logMAR 4.等於1/10000=.0001 NLP是logMAR 5.等於1/100000=0.00001
def cnvrtScale(sghtMsre):
  from re import search, IGNORECASE
  if mtchSght:=search('(CF|HM|LP|NLP)', sghtMsre, IGNORECASE):
    odMtch=mtchSght.group(0)
    #print('eyeScale', odMtch)
    sghtAfter=eyeScale.get(odMtch, 0)
  elif mtchSght:=search('(.*)cc|(.*)mmHg', sghtMsre):
    sghtAfter=mtchSght.group(1)
  elif mtchSght:=search('(\d+\.?\d*?)/(\d+\.?\d*?)', sghtMsre): #'(\d+\.?\d+?)/(\d+\.?\d+?)'
    osMtch=mtchSght.groups()
    sghtAfter=float(osMtch[0])/float(osMtch[1])
  elif isinstance(sghtMsre, float):
    sghtAfter=sghtMsre
  else:
    sghtAfter=float(sghtMsre)
  return sghtAfter

def dotPlot():
  fig = figure()
  ax = fig.add_subplot(1,1,1)
  scatter(data)
  stWrite(fig)

def dotPlot2():
  from streamlit import empty as stEmpty
  from altair import Chart #as altChart
  #from vega_datasets import data
  #source = data.cars()
  chart = stEmpty()
  for ndx in source.index:
    data_to_be_added = source.iloc[0:ndx+1, :]
    x = Chart(data_to_be_added).mark_circle(size=ndx * 10).encode(x='Horsepower', y='Miles_per_Gallon', color='Origin', tooltip=['Name', 'Origin', 'Horsepower', 'Miles_per_Gallon']).interactive()
    chart.altair_chart(x)

def plotSght(memSght=None):
    #原始, 打針, 視力=找病人(病歷號=memSght)
    原始, 打針, 視力=病人針視(病歷號=memSght)
    #paneLeft, paneRght=stColumns((3, 3)) 
    #paneLeft.
    #rndrCode(原始)
    dataframe(DataFrame.from_dict(原始), width=1300)
    打針df=DataFrame.from_dict(打針)#, columns=打針.keys())
    #paneRght.
    dataframe(打針df.T)
    視壓df=cnvrtDF(視力)
    左, 中, 右=stCLMN([1, 1, 1])
    with 左:
      dataframe(視壓df)
    with 中:
      dataframe(視力)
      dataframe(視壓df[['odIOP', 'osIOP']])
      try:line_chart(視壓df[['odIOP', 'osIOP']])  #[df.OD, df.DATE] 
      except: line_chart(視壓df[['OD', 'OS']])  #[df.OD, df.DATE] 
      dataframe(視壓df[['OD', 'OS']])  #[df.OD, df.DATE] 
    #df=df.fillna(nan)
    with 右:
      logDF=DataFrame()
      logDF['logOD']=視壓df['OD'].apply(cnvrtLOG)
      logDF['logOS']=視壓df['OS'].apply(cnvrtLOG)
      dataframe(logDF)
      line_chart(logDF)  #[df.OD, df.DATE]
def cnvrtLOG(row):
  from math import log
  from numpy import nan
  try: rsltLOG=-log(row)
  except: rsltLOG=nan
  return rsltLOG

def cnvrtDF(sghtInfo):
  from pandas import DataFrame
  from streamlit import line_chart, dataframe, code as stCode
  DATE, spcfcSght=[], []
  for dateSght in sghtInfo:
    日期, 視力=dateSght.split('@')
    DATE.append(日期)
    if isinstance(視力, str) and 視力.find('|'):
      infosght=視力.split('|')
      lnSght=len(infosght)
      if lnSght==3:
        OD, OS, IOP=infosght
        #stCode(['IOP', IOP])
        for mthsym in '+-':IOP=IOP.replace(mthsym, '')
        if IOP.find('/')!=-1: odIOP, osIOP=IOP.split('/')
        else: odIOP, osIOP=IOP, IOP
        OD, OS, odIOP, osIOP=cnvrtScale(OD), cnvrtScale(OS), cnvrtScale(odIOP), cnvrtScale(osIOP)
        spcfcSght.append([OD, OS, odIOP, osIOP])
      elif lnSght==2:
        OD, OS=infosght
        OD, OS=cnvrtScale(OD), cnvrtScale(OS)
        spcfcSght.append([OD, OS])
    elif isinstance(視力, float) or isinstance(視力, int):
      print('otherwise 視力', 視力)
    #elif isinstance(OS, float) or isinstance(OS, int):
    # print('otherwiseOS', OS)
  try:
      return DataFrame(spcfcSght, columns=['OD', 'OS', 'odIOP', 'osIOP'], dtype='float', index=DATE)
  except:
      return DataFrame(spcfcSght, columns=['OD', 'OS'], dtype='float', index=DATE)
  #line_chart(df)  #[df.OD, df.DATE]

def 折線圖(hist=None):
  from streamlit import line_chart, write as stWrite, dataframe, session_state, altair_chart, markdown
  from re import search, IGNORECASE
  #from numpy import nan
  sghtInfo=session_state['sghtInfo']
  DATE, spcfcSght=[], []
  #html('<style>section.css-1lcbmhc.e1fqkh3o0 > div.css-ng1t4o.e1fqkh3o1 > div.block-container.css-128j0gw.eknhn3m2 > div:nth-child(1) > div:nth-child(2) > div > div{display: flex; flex-direction: row; flex-wrap: wrap; justify-content: space-between;}</style>')
  for line in sghtInfo.split('\n'):
    cols=line.split('|')
    try:
      病歷號, sdate, od, os=cols[:4]
      #print('病歷號', 病歷號, mem)
      if mtchOD:=search('(\d+\.?\d*?)/(\d+\.?\d*?)', od):
        odMtch=mtchOD.groups()
        #print('odMtch', odMtch)
        od=float(odMtch[0])/float(odMtch[1])
        #od=str(od)
        #print('od', od)
      elif mtchOD:=search('(CF|HM|LP|NLP)', od, IGNORECASE):
        odMtch=mtchOD.group(0)
        #print('eyeScale', odMtch)
        od=eyeScale.get(odMtch, 0)
      else: od=0
      if mtchOS:=search('(\d+)/(\d+)', os):
        osMtch=mtchOS.groups()
        os=float(osMtch[0])/float(osMtch[1])
        #os=str(os)
        #print('os', os)
      elif mtchOD:=search('(CF|HM|NLP)', os, IGNORECASE):
        osMtch=mtchOS.group(0)
        os=eyeScale.get(osMtch, 0)
      else: os=0
    except:
      pass
      #print(line)
    if 病歷號==hist:
      #print('eyeinfo', od, os, sdate)
      spcfcSght.append([od, os])
      DATE.append(sdate)
      #spcfcSght.append([sdate, od, os])
  #stWrite(spcfcSght)
  spcfcSght=sorted(spcfcSght, key=lambda s: s[0])
  from pandas import DataFrame
  df=DataFrame(spcfcSght, columns=['OD', 'OS'], dtype='float', index=DATE)
  #df=df.fillna(nan)
  dataframe(df)
  line_chart(df)  #[df.OD, df.DATE]
