#!/usr/bin/env python
from pandas import read_csv
from numpy import nan
from sys import argv

fname=argv[1]
dfEye2=read_csv(fname, delimiter='\x06', dtype='str')   #'眼科SOAP3.csv'newEye.csv
eyeScale={'CF':.014, 'HM':.0052, 'NLP':.001}
'''
from re import search, IGNORECASE
def rtrvEyeSght(row):
    chartid, mrn2, sdate, outcome=row
    #chartid, mrn1, mrn2, sdate, outcome=row
    if mtch:=search('(.*)OD(.*)OS(.*)$,', outcome, IGNORECASE):print(chartid, sdate, mtch.groups())
dfEye2.apply(rtrvEyeSght, axis=1)

'''
from re import search, IGNORECASE, DOTALL, MULTILINE
fout, EOL=open('rsltSight.csv', 'w'), '\n'
pttrn='(.*?)O[DS]:?(.*?)O[DS]:?(.*?)'
def rtrvEyeSght(row):
    chartid, mrn1, mrn2, sdate, outcome=row
    chartid=str(chartid)    #, str(sdate)
    if outcome is nan:return
    #print('outcome', outcome)
    if mtch:=search(f'O:客觀資料\n(VA)?:?{pttrn}(IOP)?(.*)?', outcome, IGNORECASE|MULTILINE):
        rawInfo, mtchInfo=mtch.group(), mtch.groups()
        if not mtch[0]:  #isVA
            for od, os in findall('(\d+/\d+\.?\d+)', rawInfo):
                fout.write('| '.join([chartid, sdate, od, os])+EOL)
                #print('| '.join([chartid, sdate, od, os]))
        else:
            if not search('/\d', rawInfo):return
            if not mtchInfo[1].strip():
                 fout.write('| '.join((chartid, sdate)+mtchInfo[2:4])+EOL)
            else: fout.write('| '.join((chartid, sdate)+mtchInfo[1:3])+EOL)
        #print(chartid, sdate, mtch.groups())
dfEye2.apply(rtrvEyeSght, axis=1)
from streamlit import line_chart
def 折線圖():
    chart_data = pd.DataFrame( np.random.randn(20, 3), columns=['a', 'b', 'c'])
    line_chart(chart_data)
