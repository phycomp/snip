from re import search
from dbUtil import runQuery
from pandas import DataFrame
from re import search

def 合併打針(eye合併, infoEYE):
  for iviSght, iviDate in infoEYE.items():
    #print('iviSght, iviDate', iviSght, iviDate)
    ivi, sghtVsn=iviSght.split('|')
    if oriSght:=eye合併.get(ivi):
      eyeIVI=eye合併[ivi]
      if 原:=eyeIVI.get(sghtVsn):
        mergeDATE=set(原)
        [mergeDATE.add(ividate)for ividate in iviDate]
        eyeIVI.update({sghtVsn:list(mergeDATE)})
      else:
        eyeIVI.update({sghtVsn:iviDate})
    else:
      eye合併[ivi]={sghtVsn:set(iviDate)}
  #print('eye合併', eye合併)
  #print('infoEYE ', infoEYE, 'eye合併', eye合併)
  return eye合併

def 更新針視(eyeInfo, 打針視力):
  for 打針, 視力日期 in 打針視力.items():
    DATE=set()
    if 原視日:=eyeInfo.get(打針):
      for 左右, 日期 in 原視日.items():
        [DATE.add(date) for date in 日期.split('|')]
        if 新視日:=視力日期.get(左右):
          [DATE.add(date) for date in 新視日.split('|')]
          視日info={左右:'|'.join(DATE)}
          eyeInfo.update({打針:視日info})
    else:
      eyeInfo.update({打針:視力日期})
  return eyeInfo

def 病人針視(病歷號=None):
  qryRslt=runQuery(f'''select 日期, 打針, 視力 from "ODOS" where 病歷號='{病歷號}';''', db='eyeVis')
  print('unique', len(qryRslt))
  #df=DataFrame.from_dict(qryRslt)
  eyeIVI, sghtInfo={}, set()
  for 日期, 打針, 視力 in qryRslt:
    #if search('@', 打針視力):
      #打針, 視力=打針視力.split('@')
    #打針=eval(打針)
    #eyeInfo=更新針視(eyeInfo, 打針)
    打針=eval(打針)
    eyeIVI=合併打針(eyeIVI, 打針)
    #print('打針', 打針, 'eye合併', eyeIVI)
    if 日期 and 視力: sghtInfo.add('@'.join([str(日期), 視力]))
  return qryRslt, eyeIVI, sghtInfo

