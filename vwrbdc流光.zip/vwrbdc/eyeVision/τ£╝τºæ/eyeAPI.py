#!/usr/bin/env python
from fastapi import FastAPI
app = FastAPI()

#app = FastAPI(__name__, title="FastAPI CRUD Example", docs_url="/docs", redoc_url="/redocs")

from dbMnpl.strmltPGconn import runQuery

@app.post('/hist', status_code=201)
def getHIST(hist=None):
  hist眼科=runQuery('select * from ', db='')
  return hist眼科
