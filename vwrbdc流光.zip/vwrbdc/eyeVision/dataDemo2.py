from dataclasses import dataclass
from fastapi import FastAPI, Form, Depends
from starlette.responses import HTMLResponse

app = FastAPI()


@app.get("/form", response_class=HTMLResponse)
def form_get():
  return '''<form method=post id=complain_form>
<div class=form-group>
    <label for=complain>Customer complains:</label>
    <textarea type=input class="form-control" name=complain id=complain rows=3></textarea>
</div>
<button type="submit" class="btn btn-success">Submit</button>
</form>'''

@dataclass
class SimpleModel:
    no: int = Form(...)
    nm: str = Form(...)
    class Config:
      orm_mode=True


@app.post("/form", response_model=SimpleModel)
def form_post(form_data: SimpleModel = Depends()):
    return form_data
