from schemas import PthlgyContxt#, JobCreateForm#, UserAuth, User#, Token, UserOut, TokenSchema, TokenData
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
#from fastapi import FastAPI, Form
#from typing import List
from fastapi import FastAPI, File, Form, UploadFile, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pandas import read_csv
from parseVis import parseVis
from schemas import User, Token, UserOut, UserAuth, TokenSchema, TokenData

app = FastAPI()
#from os.path import dirname, join as pthJoin
#scriptDir = dirname(__file__)
#absPath = pthJoin(scriptDir, "static/")
#app.mount("/static", StaticFiles(directory=absPath), name="static")
#app.mount("/static", StaticFiles(directory="static"), name="static")
#templates = Jinja2Templates(directory="templates")
#templates = Jinja2Templates(directory=str(TEMPLATE_DIR))

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def authUser(uname: str, passwd: str):
  userDB = get_user(uname) #{'uname': 'josh', 'passwd': '$2a$08$YR70tscBQh8wKbO18j9U1O5KLqEjmBB0EQzjaBOpguKoyiyDgzWUu', 'email': 'phycomp@gmail.com'}
  if userDB:
    hashedPasswd=userDB.get('passwd')
    return False if not chkPasswd(passwd, hashedPasswd) else userDB
  else: return None

@app.post("/token", response_model=Token)
#async def login_for_access_token(formData: OAuth2PasswordRequestForm = Depends(oauth2_scheme)):
async def login_Access_Token(formData: OAuth2PasswordRequestForm = Depends()):
    uname, passwd=formData.username, formData.password
    print('uname, passwd', uname, passwd)
    userDB = authUser(uname, passwd)
    print('userDB', userDB)
    if not userDB:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="Incorrect uname or password")
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(data={"uname": userDB.get('uname')}, expires_delta=access_token_expires)
    return {"access_token": access_token, "token_type": "bearer"}

async def get_current_user(token: str = Depends(oauth2_scheme)):
    CredentialsException = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate":"Bearer"}, detail="Could not validate credentials")
    try:
      payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
      uname: str = payload.get("uname")
      if not uname: raise CredentialsException
      token_data = TokenData(uname=uname)
    except JWTError: raise CredentialsException
    print('token_data.uname=', token_data.uname)
    user = get_user(token_data.uname)
    if not user: raise CredentialsException
    return user


@app.post('/signup', summary="Create new user", response_model=User)
async def create_user(data: User):    #
    # querying database to check if user already exist
    uname, passwd, email=data.uname, data.passwd, data.email
    chkUser = allMemDB.get(uname) #, None
    chkEmail = allEmailDB.get(email) #, None
    if chkUser:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="uname already existed")
    if chkEmail:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="email already existed")
    hashedPasswd=passwdHashed(passwd)
    user = {'uname':uname, 'passwd':hashedPasswd, 'email':email}
    #db[data.email] = user    # saving user to database
    memQuery=f'''insert into "eyeVisMem" (username, passwd, email) values ('{uname}', '{hashedPasswd}', '{email}');'''
    runQuery(memQuery, commitType='update', db='BASE')
    return user

@app.post("/uploadCSV/")
async def uploadCSV(csvUpload: UploadFile=File()):    #file: bytes = File(), token:str=Form(), List[UploadFile] = File(...), files: List[bytes] = File(description="Multiple files as bytes"),
  #for file in csvUpload:
  #return {'info':csvUpload.file.read() }
  from io import BytesIO
  content=csvUpload.file.read()
  csvDF=read_csv(BytesIO(content), dtype='str')  #object, dtype='str'dtype='float',
  rsltEye=csvDF.apply(parseVis, axis=1)
  return {"ODOS": rsltEye}

@app.get("/pthlgyCntxt", response_class=HTMLResponse)
def form(request: Request):
  result = ""
  #tmplCntxt={'info':tmplCntxt}
  #return templates.TemplateResponse("item.html", {"request": request, "id": id})
  return templates.TemplateResponse('pthlgyTxtarea.html', context={'request': request, 'result': result})

@app.post("/pthlgyCntxt")  #, response_model=PthlgyContxt)  #JobCreateForm
async def pthlgyCntxt(request:Request): #, cntxtPthlgy: str = Form()):   #, password: str = Form()
  cntxtPthlgy=b''    #await request.body()    #get('pthlgy')
  from urllib.parse import unquote as prsUnquote
  async for chunk in request.stream():
    cntxtPthlgy += chunk
  #response = Response(body, media_type='text/plain')
  #print('stream', request.stream())
  #urllib.parse.urlencode
  cntxt=prsUnquote(cntxtPthlgy)
  cntxt=cntxt.replace('+', ' ').replace('\r', '')    #
  #print(cntxt)
  #print(cntxtPthlgy)
  rsltVis=parseVis(cntxt)
  return {"ODOS": rsltVis}  #'cntxtPthlgy':cntxt, 

@app.get("/")
async def main():
    content = """<body>
<form action="/files/" enctype="multipart/form-data" method="post">
<input name="files" type="file" multiple>
<input type="submit">
</form>
<form action="/uploadfiles/" enctype="multipart/form-data" method="post">
<input name="files" type="file" multiple>
<input type="submit">
</form>
</body>"""
    return HTMLResponse(content=content)

'''
  return {"file_size": len(file), "token": token, "fileb_content_type": fileb.content_type }
@app.get("/items/{item_id}")
def read_root(item_id: str, request: Request):
    client_host = request.client.host
    return {"client_host": client_host, "item_id": item_id}
'''
