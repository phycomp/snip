from typing import Optional
from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
from dataclasses import dataclass

app = FastAPI()
templates = Jinja2Templates(directory='templates')

@dataclass
class SimpleModel:
    no: int = Form(...)
    nm: str = Form(...)

@app.get("/")
def index():
    return "Hello World"

@app.post("/formPost", response_model=SimpleModel)
def formPost(no: int=Form(...), nm: str=Form(...)):
    return SimpleModel(no=no, nm=nm)

@app.get("/item/{text}")
def get_item(text: str):
    return {"result": tuple(['Hi', 'hello'])}

@app.get("/form")
def form(request: Request):
    result = ""
    return templates.TemplateResponse('form.html', context={'request': request, 'result': result})

@app.post("/form")
def form(request: Request, text: str=Form(...)):
    
    result = ['Hello', 'Hi', 'Bye'] # to simplify the example
    return templates.TemplateResponse('form.html', context={'request': request, 'result': tuple(result)})
