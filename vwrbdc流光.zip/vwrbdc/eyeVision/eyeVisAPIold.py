from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi import FastAPI, File, UploadFile, Depends, HTTPException, Request, status
from passlib.context import CryptContext

from schemas import User, Token, UserOut, UserAuth, TokenSchema, TokenData
from dbUtils import runQuery

encryptPasswd = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
app = FastAPI()

memQuery='select * from "eyeVisMem";'
allMEM=runQuery(memQuery, db='eyeVis')
allMemDB = dict(map(lambda x: (x[0], (x[1], x[2])), allMEM)) #{'josh': ('2riixdii', 'phycomp@gmail.com'), 'tao': ('2riixdii', 'tao@gmail.com')}
allEmailDB = dict(map(lambda x: (x[1], (x[0], x[2])), allMEM))

def chkPasswd(plainPasswd, hashedPasswd):
  return encryptPasswd.verify(plainPasswd, hashedPasswd)

@app.get("/users/me/", response_model=User)
def get_User_DB(uname: str):
  if uname in allMemDB:
    passwd, email=allMemDB[uname]
    return {'uname':uname, 'passwd':passwd, 'email':email}
  else: return {'uname':uname, 'passwd':'', 'email':''}

def authUser(uname: str, passwd: str):
  userDB = getUserDB(uname) #{'uname': 'josh', 'passwd': '$2a$08$YR70tscBQh8wKbO18j9U1O5KLqEjmBB0EQzjaBOpguKoyiyDgzWUu', 'email': 'phycomp@gmail.com'}
  if userDB:
    hashedPasswd=userDB.get('passwd')
    return False if not chkPasswd(passwd, hashedPasswd) else userDB
  else: return None

@app.post("/token", response_model=Token)
async def login(formData: OAuth2PasswordRequestForm = Depends()):
  uname, passwd=formData.username, formData.password
  print(uname, passwd)
  userDB = authUser(uname, passwd)
  if not userDB:
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="Incorrect uname or password")
  return {"access_token": accessToken, "token_type": "bearer"}

