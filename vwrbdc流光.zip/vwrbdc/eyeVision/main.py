import uvicorn
from fastapi import FastAPI, Request
#from fastapi import FastAPI #, Depends, HTTPException
#from .auth import AuthHandler
#from .schemas import AuthDetails
app = FastAPI()
from dbMnpl.strmltPGconn import runQuery
#auth_handler = AuthHandler()
#app = FastAPI(__name__, title="FastAPI CRUD Example", docs_url="/docs", redoc_url="/redocs")
from fastapi import FastAPI, status, HTTPException
from fastapi.responses import RedirectResponse
from schemas import UserOut, UserAuth
from fastapi import FastAPI, status, HTTPException, Depends
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
#from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import RedirectResponse
from schemas import UserOut, UserAuth, TokenSchema
#from replit import db
#from app.utils import ( get_hashed_password, create_access_token, create_refresh_token, verify_password)
#from uuid import uuid4
#from app.utils import get_hashed_password
#from uuid import uuid4

from fastapi import Depends, FastAPI
from pydantic import BaseModel

#app = FastAPI()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

from schemas import User

def fake_decode_token(token):
    return User(username=token + "fakedecoded", email="john@example.com", full_name="John Doe")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    user = fake_decode_token(token)
    return user

@app.get("/users/me")
async def read_users_me(current_user: User = Depends(get_current_user)):
    return current_user

@app.get('/hist/{hist}/', status_code=201)
def getVision(hist:str=None): #, request:Request
  #hist眼科=runQuery('select * from ', db='')
  from 眼科.srchHIST import 病人針視  #, 找病人
  原始, 打針, 視力=病人針視(病歷號=hist)
  return 視力

def filterDate(row, startDate=None, endDate=None):
    date=row[0]
    if startDate<=date<=endDate:
        return row

@app.get('/visEHR/{hist}/', status_code=201)
def getVisEHR(hist:str=None):
  SOAP手術=[v for v in runQuery(f"""select distinct "SOAP", 手術 from "OLAP"."視力手術" where 病歷號='{hist}';""", db='OLAP')]
  return SOAP手術

@app.get("/histDuration/{hist}/{startDate}/{endDate}", status_code=201)
def getDuration(hist:str=None, startDate:str=None, endDate:str=None):
  from 眼科.srchHIST import 病人針視  #, 找病人
  原始, 打針, 視力=病人針視(病歷號=hist)
  from pandas import DataFrame
  eyeVis=[v.split('@') for v in 視力]
  #eyeVis=map(mkVis, eyeVis) #list()
  eyeDF=DataFrame(eyeVis, columns=['date', 'vis'], index=None)
  #df=eyeDF[eyeDF.apply(filterDate, args=(startDate, endDate), axis=1).isnan()!=None]
  dfFlag=eyeDF.apply(filterDate, args=(startDate, endDate), axis=1)
  df=eyeDF[dfFlag.notna()]
  return df.to_csv() #.values

@app.post('/signup', summary="Create new user", response_model=UserOut)
async def create_user(data):    #: UserAuth
    # querying database to check if user already exist
    user = db.get(data.email, None)
    if user:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User with this email already exist")
    user = {'id': str(uuid4()), 'password':get_hashed_password(data.password), 'email':data.email}
    db[data.email] = user    # saving user to database
    return user

@app.post('/login', summary="Create access and refresh tokens for user", response_model=TokenSchema)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = db.get(form_data.username, None)
    if not user: # is None
        raise HTTPException( status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect email or password")

    hashed_pass = user['password']
    if not verify_password(form_data.password, hashed_pass):
        raise HTTPException( status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect email or password")
    
    return {"access_token": create_access_token(user['email']), "refresh_token": create_refresh_token(user['email']), }

"""
#from config import engine
#from config import metadata
#from config import app

#from post.route import post_route

#app.include_router(post_route, prefix="/api/post", tags=["post"])

#uvicorn main:app --reload

#uvicorn.run("main:app", host="127.0.0.1", port=8000)

@app.post('/register', status_code=201)
def register(auth_details): #: AuthDetails
    if any(x['username'] == auth_details.username for x in users):
        raise HTTPException(status_code=400, detail='Username is taken')
    hashed_password = auth_handler.get_password_hash(auth_details.password)
    users.append({ 'username': auth_details.username, 'password': hashed_password })
    return None
"""
