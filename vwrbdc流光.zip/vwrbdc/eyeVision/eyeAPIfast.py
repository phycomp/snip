from dbUtils import runQuery
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import JWTError, jwt

class User(BaseModel):
    uname: str
    passwd: str # | None = None
    email: str | None = None
    #full_name: str | None = None
    #disabled: bool | None = None

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

app = FastAPI()
memQuery='select * from isc8381."fastAPImem";'
allMEM=runQuery(memQuery, db='BASE')
allMemDB = dict(map(lambda x: (x[0], (x[1], x[2])), allMEM)) #{'josh': ('2riixdii', 'phycomp@gmail.com'), 'tao': ('2riixdii', 'tao@gmail.com')}

def get_password_hash(password):
  return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
  return pwd_context.verify(plain_password, hashed_password)

def authenticate_user(uname: str, passwd: str):
  userDB = get_user(uname)
  if userDB:
    hashedPasswd=userDB[uname][0]
    return False if not verify_password(password, hashedPasswd) else userDB
  else: return None

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate":"Bearer"}, detail="Could not validate credentials")
    try:
      payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
      username: str = payload.get("sub")
      if not username: raise credentials_exception
      token_data = TokenData(username=username)
    except JWTError: raise credentials_exception
    user = get_user(fake_users_db, username=token_data.username)
    if not user: raise credentials_exception
    return user

async def get_current_active_user(current_user: User = Depends(get_current_user)):
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

@app.get("/users/me/", response_model=User)
async def read_users_me(current_user: User = Depends(get_current_active_user)):
    return current_user

@app.get("/users/me/", response_model=User)
def get_user(uname: str):
  if uname in allMemDB:
    passwd, email=allMemDB[uname]
    return {'uname':uname, 'passwd':passwd, 'email':email}
  else: return {'uname':uname, 'passwd':'', 'email':''}
  
'''
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    uname, passwd=form_data.username, form_data.password
    user = authenticate_user(allMEM, uname, passwd)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="Incorrect username or password")
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(data={"sub": user.username}, expires_delta=access_token_expires)
    return {"access_token": access_token, "token_type": "bearer"}

#update isc8381."fastAPImem" set passwd= crypt('2riixdii', gen_salt('bf', 8)) where username='josh';
#insert into isc8381."fastAPImem" (username, passwd, email) values ('josh', '2riixdii', 'phycomp@gmail.com');
def isMem(mem, uname=None):
    memname=mem[0]  #print()
    return True if uname==memname else False

'''
