from schemas import PthlgyContxt, SimpleModel
from fastapi import FastAPI, Form #, Depends, HTTPException, status

app = FastAPI()

from fastapi import Form, File, UploadFile, Request, FastAPI
from typing import List
from fastapi.responses import HTMLResponse

app = FastAPI()

@app.post("/submit")
def submit(name: str = Form(...), point: float = Form(...), is_accepted: bool  = Form(...), files: List[UploadFile] = File(...)):
        return {"JSON Payload ": {"name": name, "point": point, "is_accepted": is_accepted}, "Filenames": [file.filename for file in files]}

@app.post("/form", response_model=SimpleModel)
def form_post(form_data: SimpleModel = Form(...)):
    return form_data

'''
templates = Jinja2Templates(directory="templates")
from fastapi.templating import Jinja2Templates
@app.get("/", response_class=HTMLResponse)
def main(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post('/eyeHR', summary="pthlgyContxt pasted", response_model=PthlgyContxt)
async def parseEyeHR(): #formData: OAuth2PasswordRequestForm = Depends()
    uname, passwd=formData.username, formData.password
    userDB = authenticate_user(uname, passwd)
'''
