from psycopg2 import connect as pgCnnct
from tomli import load as tmlLoad
from fastapi_cache.decorator import cache
fin=open('.streamlit/secrets.toml', 'rb')
secrets=tmlLoad(fin)
#db='tao'
#secrets=tmlOBJ['tao']
#cncc=connect(**db)
#@cache
def runQuery(query, db='postgres', commitType='select'):
  conn=pgCnnct(**secrets[db])
  #conn=connect(**secrets[db])
  with conn.cursor() as cur:
    if commitType=='update':
      cur.execute(query)
      conn.commit()
    else:
      cur.execute(query)
      return cur.fetchall()
