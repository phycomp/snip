from fastapi import Form, File, UploadFile, Depends, Request, Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from datetime import datetime, timedelta
from os.path import dirname, join as pthJoin
from passlib.context import CryptContext
from jose import JWTError, jwt
from dbUtils import runQuery
from json import load as jsnLoad, loads as jsnLoads, dump as jsnDump, dumps as jsnDumps
from schemas import User, Token, UserOut, UserAuth, TokenSchema, TokenData

app = FastAPI()
scriptDir = dirname(__file__)
absPath = pthJoin(scriptDir, "static/")
app.mount("/static", StaticFiles(directory=absPath), name="static")
#app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

oauthSchm = OAuth2PasswordBearer(tokenUrl="token")
cntxtPasswd = CryptContext(schemes=["bcrypt"], deprecated="auto")
memQuery='select * from "eyeVisMem";'
allMEM=runQuery(memQuery, db='eyeVis')
allMemDB = dict(map(lambda x: (x[0], (x[1], x[2])), allMEM)) #{'josh': ('2riixdii', 'phycomp@gmail.com'), 'tao': ('2riixdii', 'tao@gmail.com')}
allEmailDB = dict(map(lambda x: (x[1], (x[0], x[2])), allMEM))
ALGORITHM = "HS256"
SECRET_KEY="b5ba48693090ab1c9eeb65584e4a94fbc3c071b80765b3b36551672419a79a9d"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

def createAccessToken(data: dict, expireDelta: timedelta | None = None):
    accssToken = data.copy()
    if expireDelta:
        expire = datetime.utcnow() + expireDelta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    accssToken.update({"exp": expire})
    encodedJWT = jwt.encode(accssToken, SECRET_KEY, algorithm=ALGORITHM)
    return encodedJWT

def chkPasswd(plainPasswd, hashedPasswd):
  return cntxtPasswd.verify(plainPasswd, hashedPasswd)

def passwdHashed(password):
  return cntxtPasswd.hash(password)

@app.post('/signup', summary="Create new user", response_model=User)
async def mem_Signup(user:User):    #str=Form(), passwd:str=Form(), email:Form(...)):    #
    # querying database to check if user already exist
    uname, passwd, email=user.uname, user.passwd, user.email
    print('uname, passwd, email', uname, passwd, email)
    chkUser = allMemDB.get(uname) #, None
    chkEmail = allEmailDB.get(email) #, None
    if chkUser:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="uname already existed")
    if chkEmail:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="email already existed")
    hashedPasswd=passwdHashed(passwd)
    user = {'uname':uname, 'passwd':hashedPasswd, 'email':email}
    #db[data.email] = user    # saving user to database
    memQuery=f'''insert into "eyeVisMem" (username, passwd, email) values ('{uname}', '{hashedPasswd}', '{email}');'''
    runQuery(memQuery, commitType='update', db='eyeVis')
    return user


@app.get("/users/me/", response_model=User)
def get_User_DB(uname: str):
  if uname in allMemDB:
    passwd, email=allMemDB[uname]
    return {'uname':uname, 'passwd':passwd, 'email':email}
  else: return {'uname':uname, 'passwd':'', 'email':''}

def authUser(uname: str, passwd: str):
  userDB = get_User_DB(uname) #{'uname': 'josh', 'passwd': '$2a$08$YR70tscBQh8wKbO18j9U1O5KLqEjmBB0EQzjaBOpguKoyiyDgzWUu', 'email': 'phycomp@gmail.com'}
  if userDB:
    hashedPasswd=userDB.get('passwd')
    return False if not chkPasswd(passwd, hashedPasswd) else userDB
  else: return None

@app.post("/token", response_model=Token)
async def login(formData: OAuth2PasswordRequestForm = Depends()):
  uname, passwd=formData.username, formData.password
  userDB = authUser(uname, passwd)
  if not userDB:
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="Incorrect uname or password")
  accssTokenExpired = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
  accessToken = createAccessToken({"uname": userDB.get('uname')}, expireDelta=accssTokenExpired)
  print('bearer', accessToken, accssTokenExpired)
  return {"access_token": accessToken, "token_type": "bearer"}

def mkComponent(rsltEye, hist):
    component=[]
    rightEyeTMPL='''{
      "code": {
        "coding": [
      { "system": "http://loinc.org", "code": "79892-6", "display": "Right eye Intraocular pressure" },
      { "system" : "https://snomedbrowser.com/Codes/Details/417723001", "code" : "XaKRY", "display" : "Intraocular pressure right eye" }
        ]
      },
      "valueDateTime":"valueDT",
      "valueQuantity": { "value": "valueQnty", "unit": "mmHg", "system": "http://unitsofmeasure.org", "code": "mm[Hg]" }
    }'''
    leftEyeTMPL='''
    {
      "code": {
        "coding": [
      { "system": "http://loinc.org", "code": "79893-4", "display": "Left eye Intraocular pressure" },
      { "system" : "https://snomedbrowser.com/Codes/Details/302157000", "code" : "Xa8EM", "display" : "Intraocular pressure left eye" }
        ]
      },
      "valueDateTime":"valueDT",
      "valueQuantity": { "value": "valueQnty", "unit": "mmHg", "system": "http://unitsofmeasure.org", "code": "mm[Hg]" }
    }'''
    #obs.component.append()
    for 日期, 視力 in rsltEye:
      #eyeINFO=iopTMP.replace('iopDT', 日期)
      try: iopOD, iopOS=視力.split('|')[-1].split('/')
      except: iopOD=iopOS=視力
      #stInfo([iopOD, iopOD])
      if iopOD and iopOS:
        leRslt=leftEyeTMPL.replace('valueDT', 日期).replace('"valueQnty"', iopOS)
        reRslt=rightEyeTMPL.replace('valueDT', 日期).replace('"valueQnty"', iopOD)
    component.append(leRslt)
    component.append(reRslt)
    return component

def mkComponent2(hist, dt, vis):
    component=[]
    leftLogMAR='''{
      "code": {
        "coding": [
      { "system":"http://loinc.org", "code":"6617-5", "display":"Visual acuity log MAR.left"}
        ]
      },
      "valueDateTime":"valueDT",
      "valueQuantity": { "value": "valueQnty", "system": "http://unitsofmeasure.org", "code": "logMAR" }
    }'''
    rightLogMAR='''{
      "code": {
        "coding": [
      { "system": "http://loinc.org", "code": "6616-7", "display": "Visual acuity log MAR.right" }
        ]
      },
      "valueDateTime":"valueDT",
      "valueQuantity": { "value": "valueQnty", "system": "http://unitsofmeasure.org", "code": "logMAR" }
    }'''
    rightEyeTMPL='''{
      "code": {
        "coding": [
      { "system": "http://loinc.org", "code": "79892-6", "display": "Right eye Intraocular pressure" },
      { "system" : "https://snomedbrowser.com/Codes/Details/417723001", "code" : "XaKRY", "display" : "Intraocular pressure right eye" }
        ]
      },
      "valueDateTime":"valueDT",
      "valueQuantity": { "value": "valueQnty", "unit": "mmHg", "system": "http://unitsofmeasure.org", "code": "mm[Hg]" }
    }'''
    leftEyeTMPL='''
    {
      "code": {
        "coding": [
      { "system": "http://loinc.org", "code": "79893-4", "display": "Left eye Intraocular pressure" },
      { "system" : "https://snomedbrowser.com/Codes/Details/302157000", "code" : "Xa8EM", "display" : "Intraocular pressure left eye" }
        ]
      },
      "valueDateTime":"valueDT",
      "valueQuantity": { "value": "valueQnty", "unit": "mmHg", "system": "http://unitsofmeasure.org", "code": "mm[Hg]" }
    }'''
    #obs.component.append()
    #for 日期, 視力 in dt:
      #eyeINFO=iopTMP.replace('iopDT', 日期)
    print('vis=', vis)
    OD, OS, IOP=vis.split('|')
    if IOP.find('-')!=-1: IOP=IOP.replace('-', '')
    try: iopOD, iopOS=IOP.split('/')
    except: iopOD=iopOS=IOP
    #stInfo([iopOD, iopOD])
    if OD and OS:
      #OD, OS=str(float(OD)), str(float(OS))
      logOD=rightLogMAR.replace('valueDT', dt).replace('valueQnty', OD)
      logOS=leftLogMAR.replace('valueDT', dt).replace('valueQnty', OS)
    component.append(logOS)
    component.append(logOD)
    if iopOD and iopOS:
      leRslt=leftEyeTMPL.replace('valueDT', dt).replace('valueQnty', iopOS)
      reRslt=rightEyeTMPL.replace('valueDT', dt).replace('valueQnty', iopOD)
    component.append(leRslt)
    component.append(reRslt)
    return component

def rtrvIOP(hist):
  leftEyeTMPL=open('/home/josh/eyeVision/leftEyeIOPtmpl.json').read()
  rightEyeTMPL=open('/home/josh/eyeVision/rightEyeIOPtmpl.json').read()
  iopTMP=open('/home/josh/eyeVision/obsEyeIOP.json').read()
  rsltEye=runQuery(f'''select 日期, 視力 from "ODOS" where 病歷號='{hist}';''', db='eyeVis')
  #iopDCT=demoIOP()
  #from copy import deepcopy
  #iopDDCT = deepcopy(iopDCT)
  #iopOBJ=dict2obj(iopDDCT)
  #iopOBJ.component=[]
  tmplIOPleft, tmplIOPright=[], []
  #stInfo(['rsltEye', rsltEye])
  for 日期, 視力 in rsltEye:
    eyeINFO=iopTMP.replace('iopDT', 日期)
    try: iopOD, iopOS=視力.split('|')[-1].split('/')
    except: iopOD=iopOS=視力
    #stInfo([iopOD, iopOD])
    if iopOD and iopOS:
      rightINFO=eyeINFO.replace('valueTMPL', iopOD)
      leftINFO=eyeINFO.replace('valueTMPL', iopOS)
      tmplIOPleft.append(leftINFO)
      tmplIOPright.append(rightINFO)
    #rightOBJ.valueQuantity.value=iopOD
    #iopOBJ.effectiveDateTime=日期
    #iopOBJ.valueQuantity.value=視力
  leftEye=leftEyeTMPL.replace('"cmpnntTMPL"', ','.join(tmplIOPleft))
  rightEye=rightEyeTMPL.replace('"cmpnntTMPL"', ','.join(tmplIOPright))
  return leftEye, rightEye

def mkOBS(hist):
  from fhir.resources.observation import Observation
  rsltEye=runQuery(f'''select 日期, 視力 from "ODOS" where 病歷號='{hist}';''', db='eyeVis')
  obs=Observation(id=hist, status='final', code={})
  cmpnnt=mkComponent(rsltEye, hist)
  #print('cmpnnt=', cmpnnt)
  obs.component=[]
  for cmp in cmpnnt:
    #print('cmp=', cmp)
    cmpOBJ=jsnLoads(cmp)    #str()
    obs.component.append(cmpOBJ)
  #print('obs=', obs)
  return obs

def mkOBS2(hist, dt, vis):
  from fhir.resources.observation import Observation
  #rsltEye=runQuery(f'''select 日期, 視力 from "ODOS" where 病歷號='{hist}';''', db='eyeVis')
  obs=Observation(id=hist, status='final', code={})
  cmpnnt=mkComponent2(hist, dt, vis)
  obs.component=[]
  for cmp in cmpnnt:
    print('cmp=', cmp)
    cmpOBJ=jsnLoads(cmp)
    obs.component.append(cmpOBJ)
  return obs

@app.get('/FHIR/Patient/DiagnosticReport/{hist}', summary='23382425', status_code=201)
async def dgnstcRprt(hist:str=None, token:str=Depends(oauthSchm)): #, request:Request
  from fhir.resources.diagnosticreport import DiagnosticReport
  from fhir.resources.codeableconcept import CodeableConcept
  #rsltOBS=runQuery(f'''select 日期, 視力 from "ODOS" where 病歷號='{hist}';''', db='eyeVis')
  print(f'''select 病歷號, string_agg(日期||'@'||視力, '#' order by 日期) from "ODOS" where 病歷號='{hist}' group by 1;''')
  hist, dtVis=runQuery(f'''select 病歷號, string_agg(日期||'@'||視力, '#' order by 日期) from "ODOS" where 病歷號='{hist}' group by 1;''', db='eyeVis')[0]
  ccpt=CodeableConcept()
  dgstcRpt=DiagnosticReport(id=hist, status='final', code=ccpt)
  dgstcRpt.result=[]
  for obsRepr in dtVis.split('#'):
    dt, vis=obsRepr.split('@')
    obs=mkOBS2(hist, dt, vis)
    dgstcRpt.result.append(obs)
  return dgstcRpt.__dict__

@app.get('/FHIR/Patient/eyeIOP/{hist}', summary='23382425/Observation?code=79892-6', status_code=201)   # observation/hist/{hist}/
async def iopVision(hist:str=None, token:str=Depends(oauthSchm)): #, request:Request
  from fhir.resources.observation import Observation
  obs=Observation(id=hist, status='final', code={})
  cmpnnt=mkOBS(hist)
  obs.component=[]
  print('cmpnnt=', cmpnnt)
  for cmp in cmpnnt:
    #print('cmp=', cmp)
    cmpOBJ=jsnLoads(str(cmp))
    obs.component.append(cmpOBJ)
  return obs.__dict__   #jsnLoads()

@app.get('/FHIR/Patient/right/{hist}', summary='23382425/Observation?code=79892-6', status_code=201)   # observation/hist/{hist}/
async def rightVision(hist:str=None, token:str=Depends(oauthSchm)): #, request:Request
  rsltEye=runQuery(f'''select 日期, 視力 from "ODOS" where 病歷號='{hist}';''', db='eyeVis')
  leftEye, rightEye=mkComponent(rsltEye, hist)
  #leftEye, rightEye=rtrvIOP(hist)
  return jsnLoads(rightEye)  #', '.join([, jsnLoads(rightSTR)])    #leftSTR, rightSTR

@app.get('/FHIR/Patient/left/{hist}', summary='23382425/Observation?code=79893-4', status_code=201)   # observation/hist/{hist}/
async def leftVision(hist:str=None, token:str=Depends(oauthSchm)): #, request:Request
  leftEye, rightEye=rtrvIOP(hist)
  return jsnLoads(leftEye)  #', '.join([, jsnLoads(rightSTR)])    #leftSTR, rightSTR
  #from dbUtils import runQuery
  #leftSTR=jsnDumps(leftEye, default=lambda o: o.__dict__, sort_keys=True, indent=4)
  #rightSTR=jsnDumps(rightEye, default=lambda o: o.__dict__, sort_keys=True, indent=4)
  #stInfo([leftSTR, rightSTR])
  #print(leftSTR)  #, rightSTR
  #else: raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="no valid token")

@app.get('/hist/{hist}/', summary='32567127', status_code=201)
async def get_Vision(hist:str=None, token:str=Depends(oauthSchm)): #, request:Request
  from 眼科.srchHIST import 病人針視  #, 找病人
  原始, 打針, 視力=病人針視(病歷號=hist)
  return 視力
  #else: raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="no valid token")

@app.get("/pthlgyCntxt", response_class=HTMLResponse)
def rndr_Pthlgy(request: Request):
  return templates.TemplateResponse('pthlgyTxtarea.html', context={'request': request})   #, context={'request': request, 'result': result}

@app.post("/pthlgyCntxt")  #, response_model=PthlgyContxt)  #JobCreateForm
async def pthlgy_Cntxt(request:Request): #, cntxtPthlgy: str = Form()):   #, password: str = Form()
  cntxtPthlgy=b''    #await request.body()    #get('pthlgy')
  from urllib.parse import unquote as prsUnquote
  body=await request.body()
  #print('body', body)
  async for chunk in request.stream():
    cntxtPthlgy += chunk
  #response = Response(body, media_type='text/plain')
  #print('stream', request.stream())
  #urllib.parse.urlencode
  cntxt=prsUnquote(cntxtPthlgy)
  cntxt=cntxt.replace('+', ' ').replace('\r', '')    #
  #print(cntxt)
  #print(cntxtPthlgy)
  from parseVis import parseVis
  rsltVis=parseVis(cntxt)
  return {"ODOS": rsltVis}  #'cntxtPthlgy':cntxt, 

@app.post("/uploadCSV/")
async def upload_CSV(csvUpload: UploadFile=File()):    #file: bytes = File(), token:str=Form(), List[UploadFile] = File(...), files: List[bytes] = File(description="Multiple files as bytes"),
  #for file in csvUpload:
  #return {'info':csvUpload.file.read() }
  from io import BytesIO
  from parseVis import parseVis
  from pandas import read_csv
  content=csvUpload.file.read()
  csvDF=read_csv(BytesIO(content), dtype='str', delimiter='\x06')  #object, dtype='str'dtype='float',
  rsltEye=csvDF.apply(parseVis, axis=1)
  return {"ODOS": rsltEye}


