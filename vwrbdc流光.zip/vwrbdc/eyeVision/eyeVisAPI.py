from fastapi import Form, File, UploadFile, Depends, Request, Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from datetime import datetime, timedelta
from os.path import dirname, join as pthJoin
from passlib.context import CryptContext
from jose import JWTError, jwt
from dbUtils import runQuery
from schemas import User, Token, UserOut, UserAuth, TokenSchema, TokenData

app = FastAPI()
scriptDir = dirname(__file__)
absPath = pthJoin(scriptDir, "static/")
app.mount("/static", StaticFiles(directory=absPath), name="static")
#app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

oauthSchm = OAuth2PasswordBearer(tokenUrl="token")
cntxtPasswd = CryptContext(schemes=["bcrypt"], deprecated="auto")
memQuery='select * from "eyeVisMem";'
allMEM=runQuery(memQuery, db='eyeVis')
allMemDB = dict(map(lambda x: (x[0], (x[1], x[2])), allMEM)) #{'josh': ('2riixdii', 'phycomp@gmail.com'), 'tao': ('2riixdii', 'tao@gmail.com')}
allEmailDB = dict(map(lambda x: (x[1], (x[0], x[2])), allMEM))
ALGORITHM = "HS256"
SECRET_KEY="b5ba48693090ab1c9eeb65584e4a94fbc3c071b80765b3b36551672419a79a9d"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

def createAccessToken(data: dict, expireDelta: timedelta | None = None):
    accssToken = data.copy()
    if expireDelta:
        expire = datetime.utcnow() + expireDelta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    accssToken.update({"exp": expire})
    encodedJWT = jwt.encode(accssToken, SECRET_KEY, algorithm=ALGORITHM)
    return encodedJWT

def chkPasswd(plainPasswd, hashedPasswd):
  return cntxtPasswd.verify(plainPasswd, hashedPasswd)

def passwdHashed(password):
  return cntxtPasswd.hash(password)

@app.post('/signup', summary="Create new user", response_model=User)
async def mem_Signup(user:User):    #str=Form(), passwd:str=Form(), email:Form(...)):    #
    # querying database to check if user already exist
    uname, passwd, email=user.uname, user.passwd, user.email
    print('uname, passwd, email', uname, passwd, email)
    chkUser = allMemDB.get(uname) #, None
    chkEmail = allEmailDB.get(email) #, None
    if chkUser:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="uname already existed")
    if chkEmail:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="email already existed")
    hashedPasswd=passwdHashed(passwd)
    user = {'uname':uname, 'passwd':hashedPasswd, 'email':email}
    #db[data.email] = user    # saving user to database
    memQuery=f'''insert into "eyeVisMem" (username, passwd, email) values ('{uname}', '{hashedPasswd}', '{email}');'''
    runQuery(memQuery, commitType='update', db='eyeVis')
    return user


@app.get("/users/me/", response_model=User)
def get_User_DB(uname: str):
  if uname in allMemDB:
    passwd, email=allMemDB[uname]
    return {'uname':uname, 'passwd':passwd, 'email':email}
  else: return {'uname':uname, 'passwd':'', 'email':''}

def authUser(uname: str, passwd: str):
  userDB = get_User_DB(uname) #{'uname': 'josh', 'passwd': '$2a$08$YR70tscBQh8wKbO18j9U1O5KLqEjmBB0EQzjaBOpguKoyiyDgzWUu', 'email': 'phycomp@gmail.com'}
  if userDB:
    hashedPasswd=userDB.get('passwd')
    return False if not chkPasswd(passwd, hashedPasswd) else userDB
  else: return None

@app.post("/token", response_model=Token)
async def login(formData: OAuth2PasswordRequestForm = Depends()):
  uname, passwd=formData.username, formData.password
  userDB = authUser(uname, passwd)
  if not userDB:
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="Incorrect uname or password")
  accssTokenExpired = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
  accessToken = createAccessToken({"uname": userDB.get('uname')}, expireDelta=accssTokenExpired)
  print('bearer', accessToken, accssTokenExpired)
  return {"access_token": accessToken, "token_type": "bearer"}

@app.get('/hist/{hist}/', summary='32567127', status_code=201)
async def get_Vision(hist:str=None, token:str=Depends(oauthSchm)): #, request:Request
  from 眼科.srchHIST import 病人針視  #, 找病人
  原始, 打針, 視力=病人針視(病歷號=hist)
  return 視力
  #else: raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="no valid token")

@app.get("/pthlgyCntxt", response_class=HTMLResponse)
def rndr_Pthlgy(request: Request):
  return templates.TemplateResponse('pthlgyTxtarea.html', context={'request': request})   #, context={'request': request, 'result': result}

@app.post("/pthlgyCntxt")  #, response_model=PthlgyContxt)  #JobCreateForm
async def pthlgy_Cntxt(request:Request): #, cntxtPthlgy: str = Form()):   #, password: str = Form()
  cntxtPthlgy=b''    #await request.body()    #get('pthlgy')
  from urllib.parse import unquote as prsUnquote
  body=await request.body()
  #print('body', body)
  async for chunk in request.stream():
    cntxtPthlgy += chunk
  #response = Response(body, media_type='text/plain')
  #print('stream', request.stream())
  #urllib.parse.urlencode
  cntxt=prsUnquote(cntxtPthlgy)
  cntxt=cntxt.replace('+', ' ').replace('\r', '')    #
  #print(cntxt)
  #print(cntxtPthlgy)
  from parseVis import parseVis
  rsltVis=parseVis(cntxt)
  return {"ODOS": rsltVis}  #'cntxtPthlgy':cntxt, 

@app.post("/uploadCSV/")
async def upload_CSV(csvUpload: UploadFile=File()):    #file: bytes = File(), token:str=Form(), List[UploadFile] = File(...), files: List[bytes] = File(description="Multiple files as bytes"),
  #for file in csvUpload:
  #return {'info':csvUpload.file.read() }
  from io import BytesIO
  from parseVis import parseVis
  content=csvUpload.file.read()
  csvDF=read_csv(BytesIO(content), dtype='str')  #object, dtype='str'dtype='float',
  rsltEye=csvDF.apply(parseVis, axis=1)
  return {"ODOS": rsltEye}

