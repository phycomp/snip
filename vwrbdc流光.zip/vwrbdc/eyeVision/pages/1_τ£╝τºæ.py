from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect, dataframe, columns as stCLMN, line_chart, file_uploader as flUpldr
from stUtil import rndrCode
from 眼科.rtrvIVI import rtrvIVI
from 眼科.折線圖 import plotSght#, cnvrtDF, cnvrtLOG
from pandas import read_csv, read_excel
from dbUtil import runQuery
from pandas import DataFrame

#from streamlit import toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache, 
def vl2Float(vl):
  print('vl', vl)
  return  0 if vl=='' else float(vl)

MENU, 表單=[], ['病理找視力', '打針手術', '上傳資料', '搜索病歷號', '視力手術']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[4]:
  qryRslt=runQuery('select * from 視力手術 limit 50;', db='eyeVis')
  #dataframe(qryRslt)
  rndrCode(qryRslt)#DataFrame(data=qryRslt))
  #dataframe()
elif menu==MENU[3]:
  from 眼科.資料驗證 import dataIntegrity
  dataIntegrity()
elif menu==MENU[2]:
  csv=flUpldr('上傳CSV')
  if csv:
    csvDF=read_csv(csv, dtype='str')  #object, dtype='str'dtype='float', 
    dataframe(csvDF)
    from parseVis import parseVis
    rsltEye=csvDF.apply(parseVis, axis=1)
    rndrCode(rsltEye)
  #df=read_csv('IVILOAE.csv', delimiter='\x06', dtype='str')
  #df.apply(rtrvIVI, axis=1)
elif menu==MENU[1]:
  #from 眼科 import 折線圖
  #from streamlit.components.v1 import html
  from 眼科.折線圖 import cnvrtDF, plotSght
  from pandas import DataFrame
  from streamlit import dataframe, text_input, line_chart
  from eyeMem import eyeMem
  with sidebar:
    sghtMem=stRadio('眼科病人', eyeMem, horizontal=True, index=0)
  plotSght(memSght=sghtMem)
elif menu==MENU[0]:
  from streamlit import code as stCode, text_area
  pthlgyContxt=text_area('病理文本')
  from parseVis import parseVis
  if pthlgyContxt:
    rsltVis=parseVis(pthlgyContxt)
    rndrCode(rsltVis)
