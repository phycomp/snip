from uuid import UUID
from pydantic import BaseModel, Field

class TokenData(BaseModel):
    uname: str | None = None

class SimpleModel(BaseModel):
    no: int
    nm: str = ""

from typing import List
from typing import Optional
from fastapi import Request

class JobCreateForm:
    def __init__(self, request: Request):
        self.request: Request = request
        self.errors: List = []
        self.title: Optional[str] = None
        self.company: Optional[str] = None
        self.company_url: Optional[str] = None
        self.location: Optional[str] = None
        self.description: Optional[str] = None

class PthlgyContxt(BaseModel):
    pthlgyContxt: str | None = Field(default=None, title="The pathlogy context", max_length=300)

class Token(BaseModel):
    access_token: str
    token_type: str

class User(BaseModel):
    uname: str
    passwd: str # | None = None
    email: str | None = None
    #full_name: str | None = None
    #disabled: bool | None = None

class TokenSchema(BaseModel):
    access_token: str
    refresh_token: str
    
    
class TokenPayload(BaseModel):
    sub: str = None
    exp: int = None


class UserAuth(BaseModel):
    email: str = Field(..., description="user email")
    password: str = Field(..., min_length=5, max_length=24, description="user password")
    

class UserOut(BaseModel):
    uname: str
    passwd: str | None
    email: str | None

class SystemUser(UserOut):
    password: str
