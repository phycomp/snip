from dbUtils import runQuery
from fastapi import File, UploadFile, Depends, FastAPI, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import HTMLResponse
from jose import JWTError, jwt
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
from schemas import User, Token, UserOut, UserAuth, TokenSchema, TokenData

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
ALGORITHM = "HS256"
SECRET_KEY="b5ba48693090ab1c9eeb65584e4a94fbc3c071b80765b3b36551672419a79a9d"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

app = FastAPI()

memQuery='select * from "eyeVisMem";'
allMEM=runQuery(memQuery, db='eyeVis')
allMemDB = dict(map(lambda x: (x[0], (x[1], x[2])), allMEM)) #{'josh': ('2riixdii', 'phycomp@gmail.com'), 'tao': ('2riixdii', 'tao@gmail.com')}
allEmailDB = dict(map(lambda x: (x[1], (x[0], x[2])), allMEM))

def passwdHashed(password):
  return pwd_context.hash(password)

def chkPasswd(plain_password, hashed_password):
  return pwd_context.verify(plain_password, hashed_password)

def createAccessToken(data: dict, expireDelta: timedelta | None = None):
    to_encode = data.copy()
    if expireDelta:
        expire = datetime.utcnow() + expireDelta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encodedJWT = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encodedJWT

def authUser(uname: str, passwd: str):
  userDB = get_user(uname) #{'uname': 'josh', 'passwd': '$2a$08$YR70tscBQh8wKbO18j9U1O5KLqEjmBB0EQzjaBOpguKoyiyDgzWUu', 'email': 'phycomp@gmail.com'}
  if userDB:
    hashedPasswd=userDB.get('passwd')
    return False if not chkPasswd(passwd, hashedPasswd) else userDB
  else: return None

@app.post("/token", response_model=Token)
async def login_Access_Token(formData: OAuth2PasswordRequestForm = Depends()):
    uname, passwd=formData.username, formData.password
    userDB = authUser(uname, passwd)
    if not userDB:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"}, detail="Incorrect uname or password")
    accssTokenExpired = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    accessToken = createAccessToken(data={"uname": userDB.get('uname')}, expireDelta=accssTokenExpired)
    return {"access_token": accessToken, "token_type": "bearer"}

async def get_current_user(token: str = Depends(oauth2_scheme)):
    CredentialsException = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate":"Bearer"}, detail="Could not validate credentials")
    try:
      payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
      uname: str = payload.get("uname")
      if not uname: raise CredentialsException
      tokenData = TokenData(uname=uname)
    except JWTError: raise CredentialsException
    print('tokenData.uname=', tokenData.uname)
    user = get_user(tokenData.uname)
    if not user: raise CredentialsException
    return user

async def get_current_active_user(current_user: User = Depends(get_current_user)):
    if current_user.get('disabled'):
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

@app.get("/read_users/me/", response_model=User)
async def read_users_me(current_user: User = Depends(get_current_active_user)):
    return current_user

@app.get("/users/me/", response_model=User)
def get_user(uname: str):
  if uname in allMemDB:
    passwd, email=allMemDB[uname]
    return {'uname':uname, 'passwd':passwd, 'email':email}
  else: return {'uname':uname, 'passwd':'', 'email':''}

@app.get('/hist/{hist}/', status_code=201)
def getVision(hist:str=None): #, request:Request
  #hist眼科=runQuery('select * from ', db='')
  from 眼科.srchHIST import 病人針視  #, 找病人
  原始, 打針, 視力=病人針視(病歷號=hist)
  print('視力', 視力)
  return 視力

@app.post('/signup', summary="Create new user", response_model=User)
async def create_user(data: User):    #
    # querying database to check if user already exist
    uname, passwd, email=data.uname, data.passwd, data.email
    chkUser = allMemDB.get(uname) #, None
    chkEmail = allEmailDB.get(email) #, None
    if chkUser:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="uname already existed")
    if chkEmail:
      raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="email already existed")
    hashedPasswd=passwdHashed(passwd)
    user = {'uname':uname, 'passwd':hashedPasswd, 'email':email}
    #db[data.email] = user    # saving user to database
    memQuery=f'''insert into "eyeVisMem" (username, passwd, email) values ('{uname}', '{hashedPasswd}', '{email}');'''
    runQuery(memQuery, commitType='update', db='eyeVis')
    return user

@app.post("/uploadCSV/")
async def uploadCSV(csvUpload: UploadFile=File()):    #file: bytes = File(), token:str=Form(), List[UploadFile] = File(...), files: List[bytes] = File(description="Multiple files as bytes"),
  #for file in csvUpload:
  #return {'info':csvUpload.file.read() }
  from io import BytesIO
  content=csvUpload.file.read()
  csvDF=read_csv(BytesIO(content), dtype='str')  #object, dtype='str'dtype='float',
  rsltEye=csvDF.apply(parseVis, axis=1)
  return {"ODOS": rsltEye}

@app.get("/pthlgyCntxt", response_class=HTMLResponse)
def form(request: Request):
  result = ""
  #tmplCntxt={'info':tmplCntxt}
  #return templates.TemplateResponse("item.html", {"request": request, "id": id})
  return templates.TemplateResponse('pthlgyTxtarea.html', context={'request': request, 'result': result})

@app.post("/pthlgyCntxt")  #, response_model=PthlgyContxt)  #JobCreateForm
async def pthlgyCntxt(request:Request): #, cntxtPthlgy: str = Form()):   #, password: str = Form()
  cntxtPthlgy=b''    #await request.body()    #get('pthlgy')
  from urllib.parse import unquote as prsUnquote
  async for chunk in request.stream():
    cntxtPthlgy += chunk
  #response = Response(body, media_type='text/plain')
  #print('stream', request.stream())
  #urllib.parse.urlencode
  cntxt=prsUnquote(cntxtPthlgy)
  cntxt=cntxt.replace('+', ' ').replace('\r', '')    #
  #print(cntxt)
  #print(cntxtPthlgy)
  rsltVis=parseVis(cntxt)
  return {"ODOS": rsltVis}  #'cntxtPthlgy':cntxt, 

'''
memQuery='select * from "eyeVisMem";'
#update isc8381."fastAPImem" set passwd= crypt('2riixdii', gen_salt('bf', 8)) where uname='josh';
#insert into isc8381."fastAPImem" (uname, passwd, email) values ('josh', '2riixdii', 'phycomp@gmail.com');
def isMem(mem, uname=None):
    memname=mem[0]  #print()
    return True if uname==memname else False

'''
