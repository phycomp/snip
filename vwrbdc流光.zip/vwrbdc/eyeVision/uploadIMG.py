#import uvicorn

from datetime import datetime
from typing import List

from fastapi import FastAPI, File, Request, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

app = FastAPI()
templates = Jinja2Templates(directory="templates") # Change this path accordingly


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("uploadIMGs.html", {"request": request})


@app.post(path="/uploadImages")
async def extract_data_from_images(images: List[UploadFile] = File(...)):
    return f"Name: {images[0].filename}, now: {datetime.now()}"
