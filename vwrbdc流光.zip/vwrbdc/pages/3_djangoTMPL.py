from streamlit import sidebar, radio as stRadio, text_input#, code as stCode, write as stWrite, info as stInfo dataframe as stDataframe, session_state, subheader, markdown
from bdcMNPL.dbUtil import runQuery, queryCLMN
from bdcMNPL.rndrCode import rndrCode

  #from base64 import b64encode
MENU, 表單=[], ['djangoTMPL', 'tomlParser', 'webSnips', 'stComponent']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[2]:
  from streamlit import table as stTable, radio as stRadio, text_input, code as stCode, write as stWrite#, info as stInfo
  Web=['eventListner', 'showModal', 'grid', 'center']
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
  web=stRadio('', Web)
  if web==Web[0]:
    fname='djangoTMPL/events.html'
  elif web==Web[1]:
    fname='djangoTMPL/showModal.html'
  elif web==Web[2]:
    fname='djangoTMPL/grid.html'
  elif web==Web[3]:
    fname='djangoTMPL/grid.html'
    showTable=True
  with open(fname) as fin:
    tmplInfo=fin.read()
  if showTable:
      stTable(tmplInfo)
  else: stCode(tmplInfo)
elif menu==MENU[1]:
  from json import dumps as jsnDumps
  #from .ConfigParserAPI import ConfigParserAPI
  from streamlit import dataframe, radio as stRadio, text_input, write as stWrite, info as stInfo, code as stCode, file_uploader as flUpldr
  from os.path import splitext
  物件=flUpldr('上傳檔案')
  if 物件:
    #cpAPI=ConfigParserAPI()
    #confName=cpAPI.confName=f'{物件.name}'
    #stWrite(dir(物件))
    #stWrite(confName)
    #base, ext=splitext(confName)
    #cpAPI.confType=ext[1:]
    #cpAPI._get_parser()
    #dumpInfo=cpAPI._dump_config()
    dumpInfo=物件.read().decode('utf-8')
    stCode(dumpInfo)  #jsnPrtty
    jsnPrtty = jsnDumps(dumpInfo, sort_keys=True, indent=4)
    #物件DF=cpAPI._dump_json()#(, dtype='str')  #object, dtype='str'dtype='float', 
    rndrCode(jsnPrtty)  #jsnPrtty
if menu==MENU[3]:
  from streamlit import radio as stRadio, markdown, text_input, code as stCode, write as stWrite, info as stInfo #dataframe as stDataframe, session_state, subheader, markdown
  TMPLs=['stComponent', 'AnnttNER', 'AgraphTMPL', 'indexTMPL']
  stOption=stRadio('', TMPLs)
  stCmpnnt=text_input('', 'stComponent')
  #fname='djangoTMPL/stComponentTMPL.py'
  #markdown('pre{white-space:pre-wrap; font-size:3vh; word-break:break-word; }', unsafe_allow_html=True)
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
  if stCmpnnt:
    if stOption==TMPLs[0]:
      fname='djangoTMPL/stComponentTMPL.py'
      trgtSymbl='stComponent'
    elif stOption==TMPLs[1]:
      fname='djangoTMPL/NerTMPL.py'
      trgtSymbl='AnnttNER'
    elif stOption==TMPLs[2]:
      fname='djangoTMPL/reactTMPL.py'
      trgtSymbl='AgraphComponent'
    elif stOption==TMPLs[3]:
      fname='djangoTMPL/indexTMPL.tsx'
      trgtSymbl='NerKlss'
    with open(fname) as fin:
      tmplInfo=fin.read()
      tmplRndr=tmplInfo.replace(trgtSymbl, stCmpnnt)
      #tmplRndr=tmplInfo.replace('stComponent', stCmpnnt)
      stCode(tmplRndr)
elif menu==MENU[0]:
  mdlCRUD=['Create', 'Query', 'Update', 'Delete']
  with sidebar:
    Crud=stRadio('', mdlCRUD, horizontal=True, index=0)
    MDL=text_input('', 'Model')
    shortMDL=text_input('', 'shortModel')
  if Crud==mdlCRUD[0]:
    fname='djangoTMPL/addDjango.py'
  elif Crud==mdlCRUD[1]:
    fname='djangoTMPL/qryDjango.py'
  elif Crud==mdlCRUD[2]:
    fname='djangoTMPL/updateDjango.py'
  elif Crud==mdlCRUD[-1]:
    fname='djangoTMPL/deleteDjango.py'
  CrudURL=f'{Crud}-{shortMDL}'
  crudURL=f'{Crud.lower()}-{shortMDL}'
  CrudMDL=f'{Crud}{MDL}'
  crudMDL=CrudMDL[0].lower()+CrudMDL[1:]
  with open(fname) as fin:
    tmplInfo=fin.read()
    if MDL:
      tmplRndr=tmplInfo.replace('CrudMDL', CrudMDL)
    if Crud:
      tmplRndr=tmplRndr.replace('crudURL', crudURL)
      tmplRndr=tmplRndr.replace('CrudMDL', CrudMDL).replace('crudMDL', crudMDL)
    rndrCode(tmplRndr)
  #df=session_state['AllCancer']
  #subheader('Download')
  #stDataframe(df)
  #encdData=b64encode(df.to_csv(index=False).encode()).decode()
  #markdown(f'<a href="data:file/csv;base64,{encdData}" download="data.csv">Download CSV</a>', unsafe_allow_html=True)
  #rmst_exp = restricted_mean_survival_time(kmf_exp, t=time_limit)t=time_limit, 
  #pyplot( kmf.plot())
  #plotly_chart( kmf.plot())
elif menu==MENU[0]:
  sutraCLMN=['章節', '內容']
  rsltQuery=runQuery(f'''select {','.join(sutraCLMN)} from ;''', db='fiveClass')
  rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, columns=sutraCLMN, index=None)
  sutraDF=session_state['rsltDF']=DataFrame([['', '']], columns=sutraCLMN, index=[0])
  DF[DF.fiveClass.str.contains('', case=False)]
elif menu==MENU[1]:
  tblName='sutra'
  sutraCLMN=queryCLMN(tblSchm='public', tblName=tblName, db='sutra')
  #rndrCode(sutraCLMN)
  fullQuery=f'''select {','.join(sutraCLMN)} from {tblName} where 章節~'中庸';'''
  rsltQuery=runQuery(fullQuery, db='sutra')
  #rndrCode([fullQuery, rsltQuery])
  sutraCLMN=map(lambda x:x.replace('"', ''), sutraCLMN)
  rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, index=None, columns=sutraCLMN)
  rsltDF#[rsltDF['章節']=='中庸']
