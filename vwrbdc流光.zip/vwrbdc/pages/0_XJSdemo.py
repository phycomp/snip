from streamlit import sidebar, radio as stRadio, session_state, text_input
from bdcMNPL.dbUtil import queryCLMN, runQuery
from bdcMNPL.rndrCode import rndrCode

MENU, 表單=[], ['XJS', '先後天', '卦爻辭', '錯綜複雜', '二十四節氣']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[1]:
  tblName='sutra'
  sutraCLMN=queryCLMN(tblSchm='public', tblName=tblName, db='sutra')
  #rndrCode(sutraCLMN)
  fullQuery=f'''select {','.join(sutraCLMN)} from {tblName} where 章節~'中庸';'''
  rsltQuery=runQuery(fullQuery, db='sutra')
  #rndrCode([fullQuery, rsltQuery])
  sutraCLMN=map(lambda x:x.replace('"', ''), sutraCLMN)
  rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, index=None, columns=sutraCLMN)
  rsltDF#[rsltDF['章節']=='中庸']
elif menu==MENU[0]:
  from pathlib import Path#, PurePath
  try:
    XJS=session_state['XJS']
  except:
    xjsPath=Path('~/.gcin/XiangJingSheng.cin')
    XJS=session_state['XJS']=open(xjsPath.expanduser().resolve()).read()    #~/.gcin/Xia
  with sidebar:
    功能=['render', 'backup', 'srch']
    snip=stRadio('表單', 功能, horizontal=True, index=0)
  if srch:  #==功能[2]
    #rndrCode(df.iloc[0])  #.columns
    from re import findall, DOTALL
    from pandas import DataFrame
    from streamlit import dataframe
    所要=findall('\n\n(.*?)\n\n%chardef end', XJS, DOTALL)
    所要=所要[0].split('\n')    #map(lambda x:x, )
    rndrCode(len(所要))
    df=DataFrame(所要, columns=['欄位'], index=None)
    dset=df[df['欄位'].str.contains(srch)]    #dataframe()
    rndrCode(dset)
      #rndrCode()
    #rndrCode(['XJS', df])
  if snip==len(功能[2]):
    pass
  elif snip==功能[1]:
    bkupCMD='cp /home/josh/.gcin/XiangJingSheng.cin.ori /home/josh/.gcin/XiangJingSheng.cin'
    rndrCode(bkupCMD)
  elif snip==功能[0]:
    from streamlit import button
    CMD='''xjsMNPL.py ~/.gcin/XiangJingSheng.cin'''
    rndrCode(CMD)
    confirmEXE=button('執行？')
    if confirmEXE:
      from subprocess import run as sbprcsRUN
      CMD=CMD.split()
      sbprcsRUN(CMD)
