from srchSdbr import SrchSdbr
from stPG import runQuery
srchSdbr=SrchSdbr()
srchSdbr.authorInput
print()kkk
