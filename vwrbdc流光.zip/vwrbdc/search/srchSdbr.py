from streamlit import sidebar, text_input
SYMBLs=['RTNA', 'RTK']

class SrchSdbr:
  def __init__(self):
    #header = sidebar.header('')
    #self.ann = sidebar.text_input('input', value=0)
    self.symbl=sidebar.radio('', SYMBLs)
    self.authorInput=sidebar.text_input("by author name")
    self.userInput=sidebar.text_input("", 'by username')

