from streamlit import sidebar, cache as stCache, subheader, write, altair_chart

import pickle
import altair as alt
from sentence_transformers import SentenceTransformer
import faiss
import pandas as pd
import numpy as np

@stCache
def read_data():
    with open('acl_data.pickle', 'rb') as h:
        return pickle.load(h)

@stCache
def read_author_data():
    with open('author_data.pickle', 'rb') as h:
        return pickle.load(h)
    
@stCache
def unique_fos_level(df):
    return sorted(df['level'].unique())[1:]

def unique_fos(df, level, num):
    return list(df[df['level']==level].name.value_counts().index[:num])

@stCache(allow_output_mutation=True)
def load_bert_model(name='distilbert-base-nli-stsb-mean-tokens'):
    # Instantiate the sentence-level DistilBERT
    return SentenceTransformer(name)

@stCache
def load_faiss_index():
    with open('faiss_index.pickle', 'rb') as h:
        return pickle.load(h)

def vector_search(query, model, index, num_results=10):
    """Tranforms query to vector using a pretrained, sentence-level 
    DistilBERT model and finds similar vectors using FAISS.
    Args:
        query (str): User query that should be more than a sentence long.
        model (sentence_transformers.SentenceTransformer.SentenceTransformer)
        index (`numpy.ndarray`): FAISS index that needs to be deserialized.
        num_results (int): Number of results to return.
    Returns:
        D (:obj:`numpy.array` of `float`): Distance between results and query.
        I (:obj:`numpy.array` of `int`): Paper ID of the results.
    
    """
    vector = model.encode(list(query))
    D, I = index.search(np.array(vector).astype("float32"), k=num_results)
    return [i for i in I[0]]

def main():
    data = read_data()
    fos_level = unique_fos_level(data)
    model = load_bert_model()
    faiss_index = faiss.deserialize_index(load_faiss_index())
    author_data = read_author_data()
    
    title("ACL Publications Explorer")
    
    filter_year = sidebar.slider("Filter by year", 2000, 2020, (2000, 2020), 1)
    filter_fos_level = sidebar.selectbox(
        "Choose Field of Study level", fos_level)
    fields_of_study = unique_fos(data, filter_fos_level, 25)
    filter_fos = sidebar.multiselect(
        "Choose Fields of Study", fields_of_study)
    author_input = sidebar.text_input("Search by author name")
    # User search
    user_input = sidebar.text_area("Search by paper title")
    num_results = sidebar.slider("Number of search results", 10, 150, 10)

    
    if filter_fos and not user_input and not author_input:
        frame = data[(data.name.isin(filter_fos)) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1]))]
        color_on_fos = True
    elif filter_fos and user_input and not author_input:
        encoded_user_input = vector_search([user_input], model, faiss_index, num_results)
        frame = data[(data.name.isin(filter_fos)) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1])) & (data.id.isin(encoded_user_input))]
        color_on_fos = True
    elif filter_fos and user_input and author_input:
        ids = author_data[author_data.name==author_input]['paper_id']
        encoded_user_input = vector_search([user_input], model, faiss_index, num_results)
        frame = data[(data.name.isin(filter_fos)) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1])) & (data.id.isin(encoded_user_input)) & (data.id.isin(ids))]
        color_on_fos = True
    elif filter_fos and not user_input and author_input:
        ids = author_data[author_data.name==author_input]['paper_id']
        frame = data[(data.name.isin(filter_fos)) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1])) & (data.id.isin(ids))]
        color_on_fos = True
    elif not filter_fos and user_input and not author_input:
        encoded_user_input = vector_search([user_input], model, faiss_index, num_results)
        frame = data[data.id.isin(encoded_user_input) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1]))]
        color_on_fos = False
    elif not filter_fos and user_input and author_input:
        encoded_user_input = vector_search([user_input], model, faiss_index, num_results=150)
        ids = author_data[author_data.name==author_input]['paper_id']
        frame = data[(data.id.isin(ids)) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1])) & (data.id.isin(encoded_user_input))]
        color_on_fos = False
    elif not filter_fos and not user_input and author_input:
        ids = author_data[author_data.name==author_input]['paper_id']
        frame = data[(data.id.isin(ids)) & (data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1]))]
        color_on_fos = False
    else:
        frame = data[(data.year>=str(filter_year[0])) & (data.year<=str(filter_year[1]))]
        color_on_fos = False

    if color_on_fos:
        chart = alt.Chart(frame.drop_duplicates('id')).mark_point().encode(
            alt.X('Component 1', scale=alt.Scale(domain=(1, 16))),
            alt.Y('Component 2', scale=alt.Scale(domain=(0, 18))),
            alt.Color('name', title='Field of Study'),
            alt.Size('citations', scale=alt.Scale(range=[10,500]), title='Citations'),
            href='source:N',
            tooltip=['title', 'year']
        ).interactive().properties(width=650, height=500)

    else:
        chart = alt.Chart(frame.drop_duplicates('id')).mark_point().encode(
            alt.X('Component 1', scale=alt.Scale(domain=(1, 16))),
            alt.Y('Component 2', scale=alt.Scale(domain=(0, 18))),
            alt.Size('citations', scale=alt.Scale(range=[10,500]), title='Citations'),
            href='source:N',
            tooltip=['title', 'year']
        ).interactive().properties(width=650, height=500)

    bar_data = pd.DataFrame(frame[frame.level==filter_fos_level].groupby('name')['id'].count()).reset_index().sort_values('id', ascending=False)[:30]
    barchart = alt.Chart(bar_data).mark_bar().encode(alt.X('name', sort='-y', title='Fields of Study'), alt.Y('id', title='Count')).properties(width=650, height=150)
    c = (chart & barchart)
    altair_chart(c, use_container_width=True)

    subheader("How to use this app")
    write()

    subheader("About")
    write(
            f"""
I am [Kostas](http://kstathou.github.io/) and I work at the intersection of knowledge discovery, data engineering and scientometrics. I am a Mozilla Open Science Fellow and a Principal Data Science Researcher at Nesta. I am currently working on [Orion](https://orion-search.org/) (work in progress), an open-source knowledge discovery and research measurement tool. 

If you have any questions or would like to learn more about it, you can find me on [twitter](https://twitter.com/kstathou) or send me an email at kostas@mozillafoundation.org
    """
        )

    subheader("Appendix: Data & methods")
    write()


if __name__ == '__main__':
    main()
