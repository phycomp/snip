import nlp, lbdt, dcmvwr, vghcar, nhird
from multiapp import MultiApp
mpp=MultiApp()
mpp.addApp(dcmvwr)
mpp.addApp(vghcar)
mpp.addApp(lbdt)
mpp.addApp(nhird)
mpp.addApp(nlp)
APPs=mpp.apps#[nlp, dcmbdc]
from streamlit import radio as stRadio, sidebar
from streamlit.components.v1 import iframe

#ifrm=iframe("https://docs.streamlit.io/en/latest")
MENUs=[app for app in APPs]
app=stRadio('APPs', MENUs)#, default=APPs[0])
if app==MENUs[0]:
  dcmvwr.run()
elif app==MENUs[1]:
  'vghcar'
  vghcar.run()
elif app==MENUs[2]:
  'lbdt'
  #lbdt.run()
elif app==MENUs[3]:
  'nhird'
  nhird.run()
elif app==MENUs[-1]:
  'nlp'
  nlp.run()
  #APPs[0]['__mdl__']
