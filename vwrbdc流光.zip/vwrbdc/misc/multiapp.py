from streamlit import sidebar

class MultiApp:
    """Framework for combining multiple streamlit applications.
    Usage:
        def foo():
            st.title("Hello Foo")
        def bar():
            st.title("Hello Bar")
        app = MultiApp()
        app.add_app("Foo", foo)
        app.add_app("Bar", bar)
        app.run()
    It is also possible keep each application in a separate file.
        import foo
        import bar
        app = MultiApp()
        app.add_app("Foo", foo.app)
        app.add_app("Bar", bar.app)
        app.run()
    """
    def __init__(self):
        self.apps = {}

    def addApp(self, mdl):
        self.apps[mdl.__name__]=mdl
        #self.apps.append({ "title":mdl.__name__, "__mdl__":mdl})

    def run(self):
        app = sidebar.radio('', self.apps, format_func=lambda app: app['title'])
        #app['__mdl__']()
