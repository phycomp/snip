def showPlot():
    #plot.sin('x')
    print('showPlot')
#showPlot()
#print('showPlot')
#import plotly
#plotly.plot('sin(x)')
import plotly.express as px
from IPython.display import display, Image
import plotly.io as pio
df = px.data.election()
fig = px.scatter_ternary(df, a="Joly", b="Coderre", c="Bergeron")
#fig.show()
def show(fig):
    figFormat=pio.to_image(fig, format='png')
    #print(figFormat)
    display(Image(figFormat))
show(fig)
