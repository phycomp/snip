import 乳癌
from multiapp import MultiApp
mpp=MultiApp()
mpp.addApp(乳癌)
APPs=mpp.apps#[nlp, dcmbdc]
from streamlit import radio as stRadio, sidebar
from streamlit.components.v1 import iframe

#ifrm=iframe("https://docs.streamlit.io/en/latest")
MENUs=[app for app in APPs]
app=stRadio('APPs', MENUs)#, default=APPs[0])
if app==MENUs[0]:
  乳癌.run()
