from re import search
from streamlit import dataframe
def stageAJCC(row, allCncr, AJCC, gndrAJCC):
    rowNdx, tcdbGndr, tcdbPRIST, icdO3M=row.name, row[14], row[16], row[17]    #TCDB_HISTGY
    if tcdbPRIST:
      mainO3T, trailO3T=tcdbPRIST[:2], tcdbPRIST[3]
      icdO3T=f'{mainO3T}.{trailO3T}'
      fltrAJCC=AJCC[AJCC.O3T.apply(lambda vl:(not search('C7[012]', mainO3T) and vl =='LymphomaNotBrain') or vl!='LymphomaNotBrain')]   #"C70", "C71", "C72"
      rsltAJCC=fltrAJCC.query(f"O3MBegin<='{icdO3M}' & O3MEnd>='{icdO3M}'")
      if len(rsltAJCC)==1:
          ajccID=rsltAJCC.ChapterId.values[0]
          ajccTitle=rsltAJCC.ChapterTitle.values[0]
          ajccSchmID=rsltAJCC.SchemaId.values[0]
          ajccSchmTitle=rsltAJCC.SchemaName.values[0]
          allCncr['ajccID'][rowNdx]=ajccID
          allCncr['ajccTitle'][rowNdx]=ajccTitle
          allCncr['ajccSchmID'][rowNdx]=ajccSchmID
          allCncr['ajccSchmTitle'][rowNdx]=ajccSchmTitle
      else:
          if tcdbGndr==2:
              rsltGndrAJCC=gndrAJCC.query(f'ChapterId==37 and O3T=="{icdO3T}" and O3MBegin<={icdO3M} and O3MEnd>={icdO3M}')
          else:
              rsltGndrAJCC=gndrAJCC.query(f"ChapterId==28 and O3T=='{icdO3T}' and O3MBegin<='{icdO3M}' and O3MEnd>='{icdO3M}'")
          if len(rsltGndrAJCC)==1:
              ajccID=rsltGndrAJCC.ChapterId.values[0]
              ajccTitle=rsltGndrAJCC.ChapterTitle.values[0]
              ajccSchmID=rsltGndrAJCC.SchemaId.values[0]
              ajccSchmTitle=rsltGndrAJCC.SchemaName.values[0]
              allCncr['ajccID'][rowNdx]=ajccID
              allCncr['ajccTitle'][rowNdx]=ajccTitle
              allCncr['ajccSchmID'][rowNdx]=ajccSchmID
              allCncr['ajccSchmTitle'][rowNdx]=ajccSchmTitle
          else:
              allCncr['ajccID'][rowNdx]=None
              allCncr['ajccTitle'][rowNdx]=None
              allCncr['ajccSchmID'][rowNdx]=None
              allCncr['ajccSchmTitle'][rowNdx]=None
    else:
      allCncr['ajccID'][rowNdx]=None
      allCncr['ajccTitle'][rowNdx]=None
      allCncr['ajccSchmID'][rowNdx]=None
      allCncr['ajccSchmTitle'][rowNdx]=None
