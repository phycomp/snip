from re import search
from re import findall
rngPttrn, thrshldPttrn, pttrnThrshld='-', '\+', '[<>]=' #2-10, 1+, >=13.4 or <=15.6

#'(\w?)\$(\d+\.?\d+)'
def dataCtgry(v):
  if search(rngPttrn, v):
    vStart, vEnd=v.split('-')
    vStart, vEnd=map(lambda x:float(x), v.split('-'))
    v=(vStart+vEnd)/2
    #v=(float(vStart)+float(vEnd))/2
  elif search(thrshldPttrn, v):
    v=float(v.replace('+', ''))
  elif search(pttrnThrshld, v):
    v=float(v[2:])
  return v
def dataMnpl(Data):
  lwr, mdl, ppr=[], [], []
  for symCtgry, v, delmtr in findall('(.?)\$(.*?)([,#]|$)', Data): #'fixed me'
    #symCtgry=v[0]
    v=dataCtgry(v)
    if symCtgry=='L': lwr.append(v)
    elif symCtgry==' ': mdl.append(v)
    elif symCtgry=='H': ppr.append(v)
  return lwr, mdl, ppr
