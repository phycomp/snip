import lbdt
from multiapp import MultiApp
mpp=MultiApp()
mpp.addApp(lbdt)
APPs=mpp.apps#[nlp, dcmbdc]

#ifrm=iframe("https://docs.streamlit.io/en/latest")
MENUs=[app for app in APPs]
app=stRadio('APPs', MENUs)#, default=APPs[0])
if app==MENUs[0]:
  lbdt.run()
